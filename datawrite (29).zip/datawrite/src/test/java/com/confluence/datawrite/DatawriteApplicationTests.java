package com.confluence.datawrite;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DatawriteApplicationTests {

	@Test
	void contextLoads() {
	}

}
