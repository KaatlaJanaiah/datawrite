package com.confluence.datawrite.processor;

import com.fasterxml.jackson.core.JsonProcessingException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class ServiceProcessor {
    @Autowired
    ServiceImpl service;

    protected void dataProcessor() {
        try {
            // service.testData();

            service.createBasePages();
            service.deleteL1ToL6Pages();
            // service.createL1ToL6Pages();
            // service.updateL1ToL6Pages();
            /*service.createBasePages();
            service.deleteL1ToL6Pages();
            service.createL1ToL6Pages();
            service.updateL1ToL6Pages();*/
        } catch (Exception exception) {
            System.err.println(exception.getMessage());
        }

    }
}
