package com.confluence.datawrite.excelentities;

public class L56ExcelData {
}
