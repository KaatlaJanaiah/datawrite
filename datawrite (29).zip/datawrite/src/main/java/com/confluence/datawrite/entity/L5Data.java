package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "l5_data")
public class L5Data {

    @Id
    private Long id;
    private String l4_ccid;
    private String l4_ccid_name;
    private String l5_cid;
    private String l5_cid_name;
    private String provider_or_3rdparty;
    private String technical_services;
    private String reference_compliance_level;
    private String apis_exposed;
    private String infrastructure_diagrams;
    private String predecessors;
    private String criticality;
    private String successors;
    private String obsolescence_score;
    private String service_manager;
    private String git_repos;
    private String pipeline;
    @Column(name = "status_type")
    private String statusType;

    @Transient
    private String l6TitleList;

    @Transient
    private String pageId;
}
