package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "l5_l6_data")
public class L5L6Data {
    @Id
    private Long id;
    @Column(name="l5_cid")
    private String l5_cid;
    private String l5_cid_name;
    @Column(name="l6_cid")
    private String l6_cid;
    @Column(name="l6_cid_name")
    private String l6_cid_name;
    @Column(name = "status_type")
    private String statusType;

}
