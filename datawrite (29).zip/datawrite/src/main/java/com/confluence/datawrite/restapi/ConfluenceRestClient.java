package com.confluence.datawrite.restapi;

import com.confluence.datawrite.config.Config;
import com.confluence.datawrite.model.ParentID;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.*;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.util.List;


@Component
public class ConfluenceRestClient {

    // @Autowired
    RestTemplate restTemplate = new RestTemplate();

    @Autowired
    Config config;


    public ResponseEntity<String> writeOnConfluencePageReturnResponse(String data) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());

        HttpEntity<String> entity = new HttpEntity(data, httpHeaders);
        ResponseEntity<String> response=restTemplate
                .exchange(config.getConfluenceAPIEndPoint(), HttpMethod.POST,entity,String.class);
        // System.out.println("response:==> " +response);
        return response;
    }

    public ResponseEntity<String> getPageListFromConfluencePage(Integer start, Integer limit) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());

        HttpEntity<String> entity = new HttpEntity(httpHeaders);

        ResponseEntity<String> response=restTemplate.exchange(config.getConfluenceAPISpaceEndPoint()+"?type=page&start="+start+"&limit="+limit, HttpMethod.GET,entity,String.class);

        // System.out.println("response:==> " +response);
        return response;
    }

    public ResponseEntity<String> getPageWithTitleFromConfluencePage(String title) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());

        HttpEntity<String> entity = new HttpEntity(httpHeaders);

        ResponseEntity<String> response=restTemplate.exchange(config.getConfluenceAPIEndPoint()+"?title="+title+"&spaceKey="+config.getSpaceKey(), HttpMethod.GET,entity,String.class);
        // System.out.println("response:==> " +response);
        return response;
    }

    public void deletePageListFromConfluencePage(String pageID) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());
        HttpEntity<String> entity = new HttpEntity(httpHeaders);
        System.out.println("Delete pageID: "+ pageID);
        // restTemplate.delete(config.getConfluenceAPIEndPoint()+"/"+parentID, httpHeaders);
        restTemplate.exchange(config.getConfluenceAPIEndPoint()+"/"+pageID, HttpMethod.DELETE,entity,Object.class);
        System.out.println("Delete Successfully.");
    }
// version
    public void updatePageFromConfluencePage(String pageID, String data) {
        try {
            System.out.println("Update pageID: "+ pageID);
            HttpHeaders httpHeaders=new HttpHeaders();
            httpHeaders.setContentType(MediaType.APPLICATION_JSON);
            httpHeaders.setBasicAuth(config.getConfluenceAuthToken());
            HttpEntity<String> entity = new HttpEntity(data, httpHeaders);
            restTemplate.exchange(config.getConfluenceAPIEndPoint()+"/"+pageID, HttpMethod.PUT,entity,Object.class);
            System.out.println("Update Successfully.");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public ResponseEntity<String> getPageVersionFromConfluencePage(String pageID) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());
        HttpEntity<String> entity = new HttpEntity(httpHeaders);
        // restTemplate.delete(config.getConfluenceAPIEndPoint()+"/"+parentID, httpHeaders);
        ResponseEntity<String> response=restTemplate.exchange(config.getConfluenceAPIEndPoint()+"/"+pageID+"/version", HttpMethod.GET,entity,String.class);
        return response;
    }

    public ResponseEntity<String> getPageContentFromConfluencePage(String pageID) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());
        HttpEntity<String> entity = new HttpEntity(httpHeaders);
        ResponseEntity<String> response=restTemplate.exchange(config.getConfluenceAPIEndPoint()+"/"+pageID+"?expand=body.storage", HttpMethod.GET,entity,String.class);
        return response;
    }

    public ResponseEntity<String> getAncestorsFromConfluencePage(String pageID) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());
        HttpEntity<String> entity = new HttpEntity(httpHeaders);
        ResponseEntity<String> response=restTemplate.exchange(config.getConfluenceAPIEndPoint()+"/"+pageID+"?expand=ancestors", HttpMethod.GET,entity,String.class);
        return response;
    }

    public ResponseEntity<String> getChildPageIdsFromConfluencePage(String pageID) {
        HttpHeaders httpHeaders=new HttpHeaders();
        httpHeaders.setContentType(MediaType.APPLICATION_JSON);
        httpHeaders.setBasicAuth(config.getConfluenceAuthToken());
        HttpEntity<String> entity = new HttpEntity(httpHeaders);
        System.out.println("Get pageID: "+ pageID);
        // restTemplate.delete(config.getConfluenceAPIEndPoint()+"/"+parentID, httpHeaders);
        // /rest/api/content/1310767/child/page?expand=children.page
        ResponseEntity<String> response=restTemplate.exchange(config.getConfluenceAPIEndPoint()+"/"+pageID+"/child/page?expand=children.page", HttpMethod.GET,entity,String.class);
        System.out.println("Get Child : ."+response.getBody());
        return response;
    }
}
