package com.confluence.datawrite.processor;

import com.confluence.datawrite.config.Config;
import com.confluence.datawrite.model.RequestModel;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.poi.util.StringUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
@Component
public class ExcelDataProcessor {

    @Autowired
    private Config config;
    @Autowired
    private ExcelDataUtil excelDataUtil;

    @Autowired
    ObjectDataUtil objectDataUtil;

    public void deletePages(Integer start, Integer limit) throws JsonProcessingException {
        objectDataUtil.processDeletePages(start,limit);
    }

    public void update(String title) throws JsonProcessingException {
        String pageId=objectDataUtil.getPageIdBasedOnTitle(title);
    }

    public void dataFlow() {
        try {
            Date date=new Date();
            System.out.println("starting time"+date.getTime());
            XSSFWorkbook xssfWorkbook=excelDataUtil.getWorkbook(config.getExcelPath());

            buildBasePage(xssfWorkbook);

            businessUnit(xssfWorkbook, 4,12);

            technicalServices(xssfWorkbook);

            processL1Data(xssfWorkbook);

            processL2L3Data(xssfWorkbook, 3,4,5,6);

            processL4Data(xssfWorkbook,6,7,8, config.getTs_L4_PageKey());

            processL5Data(xssfWorkbook,8,9,10, config.getTs_L5_PageKey());

            processL6Data(xssfWorkbook,10,11, config.getTs_L6_PageKey());

            // additional methods
            processL2L3Data(xssfWorkbook, 12, 13, 14);

            processL4Data(xssfWorkbook,14,15,16, config.getTs_L4_PageKey());

            processL5Data(xssfWorkbook,16,17,18, config.getTs_L5_PageKey());

            processL6Data(xssfWorkbook,18,19, config.getTs_L6_PageKey());
            Date date1=new Date();
            System.out.println("Time Duration "+(date1.getTime()-date.getTime())+" ms");
        } catch (Exception e) {
            System.out.println("dataFlow==>"+e.getMessage());
        }

    }

    private void technicalServices(XSSFWorkbook xssfWorkbook) {
        try {
            System.out.println("===========Technical Service Start==========");
            //Technical Service
            XSSFSheet xssfSheetTSService= xssfWorkbook.getSheetAt(2);
            List<String> tsServiceHeaders=excelDataUtil.getRowCellsData(xssfSheetTSService.getRow(0));
            List<RequestModel> tsServiceRequestModels=excelDataUtil.getBaseRequestDTO(xssfSheetTSService,0,1,
                    tsServiceHeaders,objectDataUtil.getBaseTemplateMap().get(config.getTs_PageKey()));
            objectDataUtil.lastChildRequestModel(tsServiceRequestModels);
            Map<String,String> tsServicePageIDs = objectDataUtil.parentPageIDsRequestModel(tsServiceRequestModels);
            objectDataUtil.setTSMap(tsServicePageIDs);
            System.out.println("===========Technical Service End==========");
        } catch (Exception e) {
            System.err.println("technicalServices==>"+e.getMessage());
        }
    }

    private void businessUnit(XSSFWorkbook xssfWorkbook, Integer ibsSheet, Integer nonIBSSheet) {
        try {
            System.out.println("===========Business Unit Creation Start==========");
            //Business Unit
            Map<String, String> businessUnits=new HashMap<>();


            XSSFSheet xssfSheetBusinessUnit= xssfWorkbook.getSheetAt(ibsSheet);
            excelDataUtil.setBusinessUnitMaps(xssfSheetBusinessUnit,3, businessUnits);
            System.out.println("businessUnits==>"+businessUnits);

            xssfSheetBusinessUnit= xssfWorkbook.getSheetAt(nonIBSSheet);
            excelDataUtil.setBusinessUnitMaps(xssfSheetBusinessUnit,2, businessUnits);
            System.out.println("businessUnits2==>"+businessUnits);

            List<RequestModel> bsUnitRequestModels=excelDataUtil.createBusinessUnitRequestModels(businessUnits,
                    objectDataUtil.getBaseTemplateMap().get(config.getBs_PageKey()));

            System.out.println("bsUnitRequestModels==>"+bsUnitRequestModels);

            objectDataUtil.lastChildRequestModel(bsUnitRequestModels);
            Map<String,String> bsUnitPageIDs = objectDataUtil.parentPageIDsRequestModel(bsUnitRequestModels);
            System.out.println("bsUnitPageIDs==>"+bsUnitPageIDs);
            objectDataUtil.setBusinessUnits(bsUnitPageIDs);
            System.out.println("===========Business Unit Creation END==========");
        } catch (Exception e) {
            System.err.println("businessUnit==>"+e.getMessage());
        }
    }

    private void buildBasePage(XSSFWorkbook xssfWorkbook) {
        try {
            System.out.println("===========Base Page Creation Start==========");
            //Base Template
            XSSFSheet xssfSheetBaseTemplate= xssfWorkbook.getSheetAt(0);
            List<String> baseTemplateHeaders=excelDataUtil.getRowCellsData(xssfSheetBaseTemplate.getRow(0));
            List<RequestModel> baseTemplateRequestModels=excelDataUtil.getBaseRequestDTO(xssfSheetBaseTemplate,0,1,baseTemplateHeaders,null);
            objectDataUtil.lastChildRequestModel(baseTemplateRequestModels);
            Map<String,String> baseTempPageIDs = objectDataUtil.parentPageIDsRequestModel(baseTemplateRequestModels);
            objectDataUtil.setBaseTemplateMap(baseTempPageIDs);
            System.out.println("===========Base Page Creation End==========");
        } catch (Exception e) {
            System.err.println("BaseTemplate error==>"+e.getMessage());
        }
    }

    private void processL1Data(XSSFWorkbook xssfWorkbook) {
        try {
            System.out.println("===========L1 Data Process Start==========");
            //L1 Data
            XSSFSheet xssfSheetL1=xssfWorkbook.getSheetAt(3);
            List<String> l1headers=excelDataUtil.getRowCellsData(xssfSheetL1.getRow(0));
            Integer l1KeyColIndex=1;
            Integer snColIndex=0;
            Integer l1TitleTwo=2;
            String l1ParentID=objectDataUtil.getBaseTemplateMap().get(config.getIbs_PageKey());
            Map<String,String> l1KeyValues=excelDataUtil.getKeyColValues(xssfSheetL1, l1KeyColIndex,l1headers.size());
            Map<String,String> l1TitleValues=excelDataUtil.getTitleValues(xssfSheetL1,
                    l1KeyValues,l1KeyColIndex, snColIndex,l1TitleTwo,l1headers.size());

            XSSFSheet xssfSheetL2=xssfWorkbook.getSheetAt(4);
            List<String> l2headers=excelDataUtil.getRowCellsData(xssfSheetL2.getRow(0));
            Integer l2KeyColIndex=1;
            Integer l1l2MapColIndex=0;
            Integer l2TitleTwo=2;
            Map<String,String> l2TitleLinks=excelDataUtil.getTitleLinkValue(xssfSheetL2,l1KeyValues,l1l2MapColIndex,l2KeyColIndex,l2TitleTwo,l2headers.size());

            if (l1ParentID != null && !l1ParentID.isEmpty()) {
                // Get L1 Data for save
                List<RequestModel> l1requestModels = excelDataUtil.getL1RequestDTO(xssfSheetL1, l1headers, l1ParentID,
                        snColIndex, l1TitleTwo, l2TitleLinks, l1KeyColIndex,config.getIbs_PageKey());
                System.out.println("L1 Excel Total Records are: "+l1requestModels.size());
                // Save L1 Data
                objectDataUtil.lastChildRequestModel(l1requestModels);
            }
        } catch (Exception e) {
            System.err.println("BaseTemplate error==>"+e.getMessage());
        }
        System.out.println("===========L1 Data Process End==========");
    }

    private void processL2L3Data(XSSFWorkbook xssfWorkbook, Integer sheetOne, Integer sheetTwo,
                                 Integer sheetTree, Integer sheetFour) {
        try {
            System.out.println("===========L2 Data Process Start==========");

            //L1 Data
            XSSFSheet xssfSheetL1=xssfWorkbook.getSheetAt(sheetOne);
            List<String> l1headers=excelDataUtil.getRowCellsData(xssfSheetL1.getRow(0));
            Integer l1KeyColIndex=1;
            Integer snColIndex=0;
            Integer l1TitleTwo=2;
            Map<String,String> l1KeyValues=excelDataUtil.getKeyColValues(xssfSheetL1, l1KeyColIndex,l1headers.size());
            Map<String,String> l1TitleValues=excelDataUtil.getTitleValues(xssfSheetL1,
                    l1KeyValues,l1KeyColIndex, snColIndex,l1TitleTwo,l1headers.size());
            // L2 Data
            XSSFSheet xssfSheetL2=xssfWorkbook.getSheetAt(sheetTwo);
            List<String> l2headers=excelDataUtil.getRowCellsData(xssfSheetL2.getRow(0));
            Integer l2KeyColIndex=1;
            Integer l1l2MapColIndex=0;
            Integer l2TitleTwo=2;
            Map<String,String> l2KeyValues=excelDataUtil.getChildKeyColValues(xssfSheetL2, l2KeyColIndex,
                    l1KeyValues, l1l2MapColIndex,l2headers.size());

            // L3 Sheet Data
            XSSFSheet xssfSheetL3=xssfWorkbook.getSheetAt(sheetTree);
            List<String> l3headers=excelDataUtil.getRowCellsData(xssfSheetL3.getRow(0));
            Integer l3KeyColIndex=1;
            Integer l2l3MapColIndex=0;
            Integer l3TitleTwo=2;
            Map<String,String> l3KeyValues=excelDataUtil.getChildKeyColValues(xssfSheetL3, l3KeyColIndex,
                    l2KeyValues, l2l3MapColIndex,l3headers.size());

            Map<String,String> l3TitleLinks=excelDataUtil.getTitleLinkValue(xssfSheetL3,l2KeyValues,
                    l2l3MapColIndex,l3KeyColIndex,l3TitleTwo,l3headers.size());
            Map<String,String> l3TitleValues=excelDataUtil.getTitleValues(xssfSheetL3,
                    l3KeyValues,l3KeyColIndex, l3KeyColIndex,l3TitleTwo,l3headers.size());

            // L2 Data for Saving
            List<RequestModel> l2requestModels=excelDataUtil.getL2RequestModel(xssfSheetL2,l2headers,l2KeyColIndex,
                    l2TitleTwo,l3TitleLinks,"Sub Services",3);


            XSSFSheet xssfSheetL34=xssfWorkbook.getSheetAt(sheetFour);
            List<String> l34headers=excelDataUtil.getRowCellsData(xssfSheetL3.getRow(0));
            Integer l34KeyColIndex=2;
            Integer l34MapColIndex=0;
            Integer l34TitleTwo=3;

            Map<String,String> l3ChildTitleLinks=excelDataUtil.getTitleLinkValue(xssfSheetL34,l3KeyValues,
                    l34MapColIndex,l34KeyColIndex,l34TitleTwo,l34headers.size());

            if (l2requestModels != null && !l2requestModels.isEmpty()) {
                System.out.println("L2 Excel Total Records are: "+l2requestModels.size());
                List<RequestModel> l3RequestModels = excelDataUtil.parentChildRequestModel(l2requestModels, xssfSheetL3, l3headers,
                        l3KeyColIndex, l3TitleTwo, l3ChildTitleLinks, "Technical Service");
                System.out.println("===========L2 Data Process End==========");
                // Saves L3
                System.out.println("============L3 Data Process Start =========");
                System.out.println("L3 Excel Total Records are: "+l3RequestModels.size());
                objectDataUtil.lastChildRequestModel(l3RequestModels);
                System.out.println("===========L3 Data Process End==========");
            }
        } catch (Exception e) {
            System.err.println("L2 L3 error==>"+e.getMessage());
        }

    }

    private void processL2L3Data(XSSFWorkbook xssfWorkbook, Integer sheetOne,
                                 Integer sheetTwo, Integer sheetTree) {
        try {
            System.out.println("===========Non L2 Data Process Start==========");

            //L1 Data
            Map<String,String> l1KeyValues=new HashMap<>();

            // L2 Data
            XSSFSheet xssfSheetL2=xssfWorkbook.getSheetAt(sheetOne);
            List<String> l2headers=excelDataUtil.getRowCellsData(xssfSheetL2.getRow(0));
            Integer l2KeyColIndex=0;
            // Integer l1l2MapColIndex=0;
            Integer l2TitleTwo=1;
            Map<String,String> l2KeyValues=excelDataUtil.getNonChildKeyColValues(xssfSheetL2, l2KeyColIndex,
                    l2KeyColIndex,l2headers.size());
            System.out.println("l2KeyValues==>"+l2KeyValues);
            // L3 Sheet Data
            XSSFSheet xssfSheetL3=xssfWorkbook.getSheetAt(sheetTwo);
            List<String> l3headers=excelDataUtil.getRowCellsData(xssfSheetL3.getRow(0));
            Integer l3KeyColIndex=1;
            Integer l2l3MapColIndex=0;
            Integer l3TitleTwo=2;
            Map<String,String> l3KeyValues=excelDataUtil.getChildKeyColValues(xssfSheetL3, l3KeyColIndex,
                    l2KeyValues, l2l3MapColIndex,l3headers.size());

            Map<String,String> l3TitleLinks=excelDataUtil.getTitleLinkValue(xssfSheetL3,l2KeyValues,
                    l2l3MapColIndex,l3KeyColIndex,l3TitleTwo,l3headers.size());
            System.out.println("l3TitleLinks==>"+l3TitleLinks);

            // L2 Data for Saving
            List<RequestModel> l2requestModels=excelDataUtil.getL2RequestModel(xssfSheetL2,l2headers,l2KeyColIndex,
                    l2TitleTwo,l3TitleLinks,"Sub Services",2);


            XSSFSheet xssfSheetL34=xssfWorkbook.getSheetAt(sheetTree);
            List<String> l34headers=excelDataUtil.getRowCellsData(xssfSheetL3.getRow(0));
            Integer l34KeyColIndex=2;
            Integer l34MapColIndex=0;
            Integer l34TitleTwo=3;

            Map<String,String> l3ChildTitleLinks=excelDataUtil.getTitleLinkValue(xssfSheetL34,l3KeyValues,
                    l34MapColIndex,l34KeyColIndex,l34TitleTwo,l34headers.size());

            if (l2requestModels != null && !l2requestModels.isEmpty()) {
                System.out.println("Non L2 Excel Total Records are: "+l2requestModels.size());
                List<RequestModel> l3RequestModels = excelDataUtil.parentChildRequestModel(l2requestModels, xssfSheetL3, l3headers,
                        l3KeyColIndex, l3TitleTwo, l3ChildTitleLinks, "Technical Service");
                System.out.println("===========L2 Data Process End==========");
                // Saves L3
                System.out.println("============L3 Data Process Start =========");
                System.out.println("Non L3 Excel Total Records are: "+l3RequestModels.size());
                objectDataUtil.lastChildRequestModel(l3RequestModels);
                System.out.println("===========L3 Data Process End==========");
            }
        } catch (Exception e) {
            System.err.println("L2 L3 error==>"+e.getMessage());
        }

    }



    private void processL4Data(XSSFWorkbook xssfWorkbook, Integer parentSheetIndex, Integer currentSheetIndex,
                               Integer childSheetIndex, String pageKey) {
        try {
            System.out.println("===========L4 Data Process Start==========");
            String parentID = objectDataUtil.getTSMap().get(pageKey);
            if (currentSheetIndex != null && StringUtil.isNotBlank(parentID)) {
                // Current Sheet Data
                XSSFSheet currentSheet = xssfWorkbook.getSheetAt(currentSheetIndex);
                List<String> currentHeaders = excelDataUtil.getRowCellsData(currentSheet.getRow(0));
                Integer currentTitleOneIndex = 1;
                Integer currentTitleTwoIndex = 2;
                Integer childMapIndex = 3;
                Map<String, String> childLinks = null;
                if (childSheetIndex != null) {
                    // L45 Sheet Data
                    XSSFSheet xssfSheetL45 = xssfWorkbook.getSheetAt(childSheetIndex);
                    List<String> l45headers = excelDataUtil.getRowCellsData(xssfSheetL45.getRow(0));
                    Integer currentSheetKey = 0;
                    Integer childTitleOne = 1;
                    Integer childTitleTwo = 2;
                    childLinks = excelDataUtil.getListOfLinks(xssfSheetL45, currentSheetKey, childTitleOne, childTitleTwo, l45headers.size());
                }
                List<RequestModel> l4RequestModels = excelDataUtil.getSheetRequestModel(currentSheet, currentHeaders, currentTitleOneIndex, currentTitleTwoIndex,
                        parentID,  "Sub Technical Service", childLinks, childMapIndex);
                System.out.println("=====L4 Excel Total Records are: " + l4RequestModels.size());

                objectDataUtil.lastChildRequestModel(l4RequestModels);
                System.out.println("===L4 Data Process End");
            }
        } catch (Exception e) {
            System.err.println("L4 error==>"+e.getMessage());
        }

    }

    private Map<String,String> getL4TitlesMaps(XSSFWorkbook xssfWorkbook, Integer l4SheetIndex) {
        XSSFSheet xssfSheet=xssfWorkbook.getSheetAt(l4SheetIndex);
        List<String> headers=excelDataUtil.getRowCellsData(xssfSheet.getRow(0));
        return excelDataUtil.getL4Titles(xssfSheet,3,1,2,headers.size());
    }

    private void processL5Data(XSSFWorkbook xssfWorkbook, Integer parentSheetIndex, Integer currentSheetIndex,
                               Integer childSheetIndex, String pageKey) {
        try {
            System.out.println("===========L5 Data Process Start==========");
            String parentID = objectDataUtil.getTSMap().get(pageKey);
            if (currentSheetIndex != null && StringUtil.isNotBlank(parentID)) {

                // Current Sheet Data
                XSSFSheet currentSheet = xssfWorkbook.getSheetAt(currentSheetIndex);
                List<String> currentHeaders = excelDataUtil.getRowCellsData(currentSheet.getRow(0));
                Integer currentTitleOneIndex = 1;
                Integer currentTitleTwoIndex = 2;
                Integer childMapIndex = 1;
                Map<String, String> childLinks = null;
                if (childSheetIndex != null) {
                    // L56 Sheet Data
                    XSSFSheet xssfSheetL45 = xssfWorkbook.getSheetAt(childSheetIndex);
                    List<String> l45headers = excelDataUtil.getRowCellsData(xssfSheetL45.getRow(0));
                    Integer currentSheetKey = 0;
                    Integer childTitleOne = 2;
                    Integer childTitleTwo = 3;
                    childLinks = excelDataUtil.getListOfLinks(xssfSheetL45, currentSheetKey, childTitleOne, childTitleTwo, l45headers.size());
                }
                List<RequestModel> l5RequestModels = excelDataUtil.getSheetRequestModel(currentSheet, currentHeaders, currentTitleOneIndex, currentTitleTwoIndex,
                        parentID, "Sub Technical Service", childLinks, childMapIndex);
                System.out.println("=====L5 Excel Total Records are: " + l5RequestModels.size());

                objectDataUtil.lastChildRequestModel(l5RequestModels);
                System.out.println("===L5 Data Process End");
            }
        } catch (Exception e) {
            System.err.println("L2 L3 error==>"+e.getMessage());
        }

    }

    private void processL6Data(XSSFWorkbook xssfWorkbook, Integer parentSheetIndex, Integer currentSheetIndex,
                               String pageKey) {
        try {
            System.out.println("===========L6 Data Process Start==========");
            String parentID = objectDataUtil.getTSMap().get(pageKey);
            if (currentSheetIndex != null && StringUtil.isNotBlank(parentID)) {

                // Current Sheet Data
                XSSFSheet currentSheet = xssfWorkbook.getSheetAt(currentSheetIndex);
                List<String> currentHeaders = excelDataUtil.getRowCellsData(currentSheet.getRow(0));
                Integer currentTitleOneIndex = 1;
                Integer currentTitleTwoIndex = 2;

                List<RequestModel> l6RequestModels = excelDataUtil.getSheetRequestModel(currentSheet, currentHeaders, currentTitleOneIndex, currentTitleTwoIndex,
                        parentID,  "Sub Technical Service", null, null);
                System.out.println("=====L6 Excel Total Records are: " + l6RequestModels.size());

                objectDataUtil.lastChildRequestModel(l6RequestModels);
                System.out.println("===L6 Data Process End");
            }
        } catch (Exception e) {
            System.err.println("L6 error==>"+e.getMessage());
        }

    }
}
