package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.BaseTemplate;
import com.confluence.datawrite.entity.L1Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;


import java.util.Optional;
@Repository
public interface BaseTemplateRepository extends JpaRepository<BaseTemplate, Long> {
    Optional<BaseTemplate> findByTemplateName(String templateName);
}
