package com.confluence.datawrite.excelentities;

public class L3ExcelData {
}
