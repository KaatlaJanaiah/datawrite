package com.confluence.datawrite.passiveentities;

public class PassiveL45Data {
}
