package com.confluence.datawrite.model;

import lombok.Data;

import java.util.List;
@Data
public class ConfluenceStorage {
    private String representation;
    private String value;
    private List embeddedContent;
    private Object _expandable;
}
