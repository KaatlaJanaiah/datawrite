package com.confluence.datawrite.model;

import lombok.Data;

@Data
public class Storage {
    private String representation;
    private String value;
}
