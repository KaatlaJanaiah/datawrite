package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "l3_data")
public class L3Data {
    @Id
    private Long id;
    @Column(name="l2_sid")
    private String l2Sid;
    @Column(name="l2_service_name")
    private String l2ServiceName;
    @Column(name="l3_ssid")
    private String l3Ssid;
    @Column(name="l3_name")
    private String l3Name;
    @Column(name="service_name")
    private String serviceName;
    @Column(name="business_unit")
    private String businessUnit;
    @Column(name="assignment_group")
    private String assignmentGroup;
    @Column(name="sub_service_id")
    private String subServiceId;
    @Column(name="data_type")
    private String dataType;
    @Column(name="data_source")
    private String dataSource;
    @Column(name="data_set_description")
    private String dataSetDescription;
    @Column(name="data_owner")
    private String dataOwner;
    @Column(name="service_criticality")
    private String serviceCriticality;
    @Column(name="sla_no")
    private String slaNo;
    @Column(name="schemes")
    private String schemes;
    @Column(name="service_manager")
    private String serviceManager;
    @Column(name="policies")
    private String policies;

    @Column(name = "status_type")
    private String statusType;

    @Transient
    private String l4TitleList;

    @Transient
    private String pageId;
}
