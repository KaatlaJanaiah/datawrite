package com.confluence.datawrite.processor;

import com.confluence.datawrite.config.Config;
import com.confluence.datawrite.model.*;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class DataUtil {
    @Autowired
    Config config;


    public String failedMsg() {
        return config.getFail();
    }

    public String buildTable(StringBuffer data) {
        StringBuffer sb=new StringBuffer();
        sb.append("<div>");
        sb.append("<table>");
        sb.append(data);
        sb.append("</table>");
        sb.append("</div>");
        return sb.toString();
    }

    public String layOutTemplate(String title,String data) {
        return layOutTemplate(title,data,"No-links",false);
    }


    /*public String layOutTemplate(String data,String links) {
        StringBuffer sb=new StringBuffer();
        sb.append("<div style=\"height:100%;\">");
        sb.append("<div>");
        sb.append(data);
        sb.append("</div>");
        sb.append("<div>");
        sb.append("<table>");
        sb.append(links!=null?links:"");
        sb.append("</table>");
        sb.append("</div>");
        sb.append("<div  style=\"height:150px;overflow: auto;\">");
        sb.append("<h4 style=\"background-color:#f0f0f0;color: #172b4d;height:20px;width:100px;\"> User Section</h4>");
        sb.append("<table style=\"height:100px;\">");
        sb.append("</table>");
        sb.append("</div>");
        sb.append("<div>");// #172b4d
        sb.append("<h4 style=\"background-color:'#f0f0f0';color: #172b4d;height:20px;width:100px;\">Graphic</h4>");
        sb.append("<table style=\"border-color:'#172b4d';height:97%;\">");
        sb.append("</table>");
        sb.append("</div>");
        sb.append("</div>");
        return sb.toString();
    }*/

    public String layOutTemplate(String title,String data,String links) {
        StringBuffer sb=new StringBuffer();
        sb.append("<div style=\"height:100%;\">");
        sb.append("<div>");
        sb.append(tablePanel(title, data));
        sb.append("</div>");
        sb.append("<div>");
        sb.append(links!=null?linkPanel(title, links):"");
        sb.append("</div>");
        sb.append("<div>");
        sb.append(userSectionPanel(title,getUserSection()));
        sb.append("</div>");
        sb.append("<div>");
        sb.append(graphSectionPanel(title,formLinkGraph(title)));
        sb.append("</div>");
        sb.append("</div>");
        return sb.toString();
    }

    public String layOutTemplate(String title,String data,String links, boolean child) {
        StringBuffer sb=new StringBuffer();
        sb.append("<div style=\"height:100%;\">");
        sb.append("<div>");
        sb.append(tablePanel(title, data));
        sb.append("</div>");
        sb.append("<div>");
        sb.append(links!=null?linkPanel(title, links):"");
        sb.append("</div>");
        sb.append("<div>");
        sb.append(userSectionPanel(title,getUserSection()));
        sb.append("</div>");
        sb.append("<div>");
        if (child)
          sb.append(graphSectionPanel(title,formLinkGraph(title)));
        else sb.append("<p>Link Graph Not Available</p>");
        sb.append("</div>");
        sb.append("</div>");
        return sb.toString();
    }

    private String getUserSection() {
        StringBuffer sb=new StringBuffer();
        sb.append("<div  style=\"height:150px;overflow: auto;\">");
        // sb.append("<h4 style=\"background-color:#f0f0f0;color: #172b4d;height:20px;width:100px;\">User Section</h4>");
        sb.append("<table style=\"height:100px;\">");
        sb.append("</table>");
        sb.append("</div>");
        return sb.toString();
    }

    /*private String getLinkGraphSection() {
        StringBuffer sb=new StringBuffer();
        sb.append("<div>");// #172b4d
        sb.append("<h4 style=\"background-color:'#f0f0f0';color: #172b4d;height:20px;width:100px;\">Graphic</h4>");
        sb.append("<table style=\"border-color:'#172b4d';height:97%;\">");
        sb.append("</table>");
        sb.append("</div>");
        return sb.toString();
    }*/

    public String chartLinks() {
        StringBuffer sb=new StringBuffer();
        sb.append("<ac:structured-macro ac:name=\"html\">" +
                "    <ac:parameter ac:name=\"type\">line</ac:parameter>" +
                "    <ac:parameter ac:name=\"height\">400</ac:parameter>" +
                "    <ac:parameter ac:name=\"width\">400</ac:parameter>" +
                "   <ac:parameter ac:name=\"domainAxisLabelAngel\">up45</ac:parameter>" +
                "   <ac:parameter ac:name=\"categoryLabelPosition\">up90</ac:parameter>" +
                "   <ac:rich-text-body>" +
                "        <table>" +
                "            <thead>" +
                "                <tr><td>a</td><td>b</td><td>c</td></tr>" +
                "           </thead>" +
                "           <tbody>" +
                "              <tr><td>1</td><td>2</td><td>3</td></tr>" +
                "              <tr><td>6</td><td>6</td><td>7</td></tr>" +
                "              <tr><td>11</td><td>12</td><td>13</td></tr>" +
                "          </tbody>" +
                "        </table>" +
                /*"    </ac:rich-text-body>" +*/
                "</ac:structured-macro>");
        return sb.toString();
    }


    public String tablePanel(String title, String data) {
        StringBuffer sb=new StringBuffer();
        // "  <ac:parameter ac:name=\"bgColor\">#72bc72</ac:parameter>" +
        // "  <ac:parameter ac:name=\"titleColor\">white</ac:parameter>" +
        sb.append("<ac:structured-macro ac:name=\"panel\" ac:macro-id=\"table_"+title+"\">" +

                "  <ac:parameter ac:name=\"titleBGColor\">#F2F4FA</ac:parameter>" +
                "  <ac:parameter ac:name=\"title\">Table Data</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderStyle\">dashed</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderColor\">Gray</ac:parameter>" +

                "  <ac:rich-text-body>" +
                data+
                "  </ac:rich-text-body>" +
                "</ac:structured-macro>");
        return sb.toString();
    }

    public String linkPanel(String title,String data) {
        StringBuffer sb=new StringBuffer();
        sb.append("<ac:structured-macro ac:name=\"panel\" ac:macro-id=\"links_"+title+"\">" +
                "  <ac:parameter ac:name=\"titleBGColor\">#F2F4FA</ac:parameter>" +
                "  <ac:parameter ac:name=\"title\">Child Links</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderStyle\">dashed</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderColor\">Gray</ac:parameter>" +

                "  <ac:rich-text-body>" +
                data+
                "  </ac:rich-text-body>" +
                "</ac:structured-macro>");
        return sb.toString();
    }

    public String userSectionPanel(String title,String data) {
        StringBuffer sb=new StringBuffer();
        sb.append("<ac:structured-macro ac:name=\"panel\" ac:macro-id=\"userSection_"+title+"\">" +
                "  <ac:parameter ac:name=\"titleBGColor\">#F2F4FA</ac:parameter>" +
                "  <ac:parameter ac:name=\"title\">User Section</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderStyle\">dashed</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderColor\">Gray</ac:parameter>" +

                "  <ac:rich-text-body>" +
                data+
                "  </ac:rich-text-body>" +
                "</ac:structured-macro>");
        return sb.toString();
    }

    public String graphSectionPanel(String title,String data) {
        StringBuffer sb=new StringBuffer();
        sb.append("<ac:structured-macro ac:name=\"panel\" ac:macro-id=\"graphSection_"+title+"\">" +
                "  <ac:parameter ac:name=\"titleBGColor\">#F2F4FA</ac:parameter>" +
                "  <ac:parameter ac:name=\"title\">Data</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderStyle\">dashed</ac:parameter>" +
                "  <ac:parameter ac:name=\"borderColor\">Gray</ac:parameter>" +
                "  <ac:rich-text-body>" +
                data+
                "  </ac:rich-text-body>" +
                "</ac:structured-macro>");
        return sb.toString();
    }

    public String formLinkGraph(String title) {
        StringBuffer sb=new StringBuffer();
        sb.append("<ac:structured-macro ac:name=\"linkgraph\" ac:schema-version=\"1\" ac:macro-id=\"linkGraphSec_"+title+"\">" +
                "<ac:parameter ac:name=\"outgoingLinkLevels\">6</ac:parameter>" +
                "<ac:parameter ac:name=\"format\">SVG</ac:parameter>" +
                "<ac:parameter ac:name=\"incomingLinkLevels\">6</ac:parameter>" +
                "<ac:parameter ac:name=\"direction\">LR</ac:parameter>" +
                "</ac:structured-macro>");
        return sb.toString();
    }

    public String formLinkGraphTest(String outLinks, String inLinks) {
        StringBuffer sb=new StringBuffer();
        sb.append("<ac:layout-section ac:type=\"single\">" +
                "<ac:layout-cell>" +
                "<p>" +
                "<ac:structured-macro ac:name=\"linkgraph\" ac:schema-version=\"1\" ac:macro-id=\"4a6ad155-33d9-4b43-95c3-6588fc3f524c\">" +
                "<ac:parameter ac:name=\""+outLinks+"\">"+outLinks+"</ac:parameter>" +
                "<ac:parameter ac:name=\"format\">SVG</ac:parameter>" +
                "<ac:parameter ac:name=\""+inLinks+"\">"+inLinks+"</ac:parameter>" +
                "<ac:parameter ac:name=\"labels\">ibs</ac:parameter>" +
                "</ac:structured-macro>" +
                "</p>" +
                "</ac:layout-cell>" +
                "</ac:layout-section>");
        return sb.toString();
    }

    public String getParentHyperLink(String parentTitle) {
        StringBuffer sb=new StringBuffer();
        sb.append("<p> Parent Link: ");
        sb.append("<ac:link>");
        sb.append("<ri:page ri:content-title=\""+parentTitle+"\" />");
        sb.append(parentTitle);
        sb.append("</ac:link>");
        sb.append("</p>");
        return sb.toString();
    }

    public String setGraphLinkWithLayout(String layout, String graphLink) {
        StringBuffer sb=new StringBuffer();
        sb.append("<div style=\"height:100%;\">");
        sb.append("<div>");
        sb.append(layout);
        sb.append("</div>");
        sb.append("<div>");
        sb.append(graphLink);
        sb.append("</div>");
        sb.append("</div>");
        return sb.toString();
    }

    public String buildTR(String data) {
        String tr="<tr>"+data+"</tr>";
        return tr;
    }

    public String buildTH(String data) {
        String tr="<th style=\"width:140px;\">"+data+"</th>";
        return tr;
    }

    public String buildTD(String data) {
        String tr="<td>"+data+"</td>";
        return tr;
    }

    public String buildTR(String key, String value) {
        String tr="<tr><th>"+key+"</th><td>"+value+"</td></tr>";
        return tr;
    }

    public String buildUL(String data) {
        String ul="<ul>"+data+"</ul>";
        return ul;
    }

    public String buildLI(String data) {
        String tr="<li>"+data+"</li>";
        return tr;
    }

    public String getHyperLink(String childTitle) {
        StringBuffer sb=new StringBuffer();
        sb.append("<p>");
        sb.append("<ac:link>");
        sb.append("<ri:page ri:content-title=\""+childTitle+"\" />");
        sb.append(childTitle);
        sb.append("</ac:link>");
        sb.append("</p>");
        return sb.toString();
    }

    public RequestDTO getBasicRequestDTO(String title) {
        RequestDTO requestDTO = new RequestDTO();
        requestDTO.setType("page");
        requestDTO.setTitle(title);
        requestDTO.setSpace(getSpace());
        return requestDTO;
    }

    public RequestDTO getBasicRequestDTO() {
        RequestDTO requestDTO = new RequestDTO();
        requestDTO.setType("page");
        requestDTO.setSpace(getSpace());
        return requestDTO;
    }

    public Space getSpace() {
        Space space = new Space();
        space.setKey(config.getSpaceKey());
        return space;
    }

    public Body getBody(String data) {
        Body body = new Body();
        Storage storage = new Storage();
        storage.setRepresentation("storage");
        storage.setValue(data);
        body.setStorage(storage);
        return body;
    }

    public List<Ancestor> getListAncestor(String parentId) {
        List<Ancestor> ancestors = new ArrayList<Ancestor>();
        Ancestor ancestor = new Ancestor();
        ancestor.setId(parentId);
        ancestor.setType("page");
        ancestors.add(ancestor);
        return ancestors;
    }

    ObjectMapper mapper = new ObjectMapper();

    public String getParentID(String responseBody) {
        String s[]=responseBody.split(",", 3);
        String pageId="";
        try {
            if (s.length>1) {
                String jsonStr=s[0];
                if (jsonStr != null && !jsonStr.isEmpty() && jsonStr.contains("id")) {
                    ParentID rt = mapper.readValue(jsonStr + "}", ParentID.class);
                    pageId = rt.getId();
                }
            }
        } catch (Exception e) {
            System.err.println("getParentID=="+e.getMessage());
        }
        return pageId;
    }

    public List<ParentID> getParentID(ResponseEntity<List> responseEntity) {
        List list=responseEntity.getBody();
        List<ParentID> pageIdList=new ArrayList<>();
        try {
            for (int i=0;i<list.size();i++) {
                String jsonStr=""+list.get(i);
                if (jsonStr.contains("id")) {
                    ParentID rt = mapper.readValue(jsonStr, ParentID.class);
                    System.out.println("pageId ==>"+rt.getId());
                    pageIdList.add(rt);
                }
            }
        } catch (Exception e) {
            System.err.println("getParentID=="+e.getMessage());
        }
        return pageIdList;
    }

}
