package com.confluence.datawrite.excelentities;

public class L34ExcelData {
}
