package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "basetemplate")
public class BaseTemplate {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    @Column(name = "template_name")
    private String templateName;
    @Column(name = "page_id")
    private String pageId;
}
