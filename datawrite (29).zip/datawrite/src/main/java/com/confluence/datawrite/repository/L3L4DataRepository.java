package com.confluence.datawrite.repository;

import com.confluence.datawrite.config.AppConstants;
import com.confluence.datawrite.entity.L3Data;
import com.confluence.datawrite.entity.L3L4Data;
import com.confluence.datawrite.entity.L4Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface L3L4DataRepository extends JpaRepository<L3L4Data, Long> {
    public static final String FIND_L3ChildTitles = "SELECT ssid, concat(l4_software_licence_external_id, ' - ', l4_application_name) FROM l3_l4_data where status_type !='"+ AppConstants.StatusDelete +"'";

    public static final String FIND_L4ParentTitles = "SELECT concat(ssid, ' - ', l3_service_name) FROM l3_l4_data where l4_software_licence_external_id=?"; // status_type ='"+ AppConstants.StatusDelete +"' and

    @Query(value = FIND_L3ChildTitles, nativeQuery = true)
    public List<Object[]> findL3KeyL4Titles();

    @Query(value = FIND_L4ParentTitles, nativeQuery = true)
    public List<Object[]> findL4KeyL3Titles(String l4Id);

    List<L3L4Data> findByStatusType(String statusType);
}
