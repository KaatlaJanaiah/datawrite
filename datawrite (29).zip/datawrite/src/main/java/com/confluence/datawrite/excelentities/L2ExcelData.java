package com.confluence.datawrite.excelentities;

public class L2ExcelData {
}
