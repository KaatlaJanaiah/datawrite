package com.confluence.datawrite.config;

public interface AppConstants {
    String fail="Failed";
    String StatusNew="New";
    String StatusUpdate="Update";
    String StatusDelete="Delete";
    String l1ChildLinkName="Business Service";
    String l2ChildLinkName="Sub Business Service";
    String l3ChildLinkName="Technical Service";
    String l4ChildLinkName="Business Service";
    String l5ChildLinkName="Business Service";
}
