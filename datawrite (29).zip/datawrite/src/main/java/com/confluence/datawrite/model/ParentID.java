package com.confluence.datawrite.model;

import lombok.Data;

import java.util.List;

@Data
public class ParentID {
    private String id;
}
