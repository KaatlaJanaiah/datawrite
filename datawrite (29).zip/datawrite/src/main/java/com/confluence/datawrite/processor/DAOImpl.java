package com.confluence.datawrite.processor;

import com.confluence.datawrite.entity.*;
import com.confluence.datawrite.repository.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public class DAOImpl {
    @Autowired
    private BaseTemplateRepository baseTemplateRepository;
    @Autowired
    private L1DataRepository l1DataRepository;

    @Autowired
    private BusinessUnitsRepository businessUnitsRepository;

    @Autowired
    private L2DataRepository l2DataRepository;

    @Autowired
    private L3DataRepository l3DataRepository;

    @Autowired
    private L3L4DataRepository l3L4DataRepository;

    @Autowired
    private TechnicalServiceTemplateRepository technicalServiceTemplateRepository;

    @Autowired
    private L4DataRepository l4DataRepository;

    @Autowired
    private L4L5DataRepository l4L5DataRepository;

    @Autowired
    private L5DataRepository l5DataRepository;

    @Autowired
    private L6DataRepository l6DataRepository;
    @Autowired
    private L5L6DataRepository l5L6DataRepository;

    public BaseTemplate getBaseTemplate(String templateName) {
        Optional<BaseTemplate> optionalBaseTemplate=baseTemplateRepository.findByTemplateName(templateName);
        BaseTemplate baseTemplate=optionalBaseTemplate.orElse(null);
        return baseTemplate;
    }

    public List<L1Data> getL1Data() {
        return l1DataRepository.findAll();
    }

    public List<L1Data> getL1Data(String status_type) {
        return l1DataRepository.findByStatusType(status_type);
    }

    public List<Object[]> getL2TitlesData() {
        return l2DataRepository.findL1KeyL2Titles();
    }

    public List<Object[]> businessUnitsForCreate() {
        return l2DataRepository.businessUnitsForCreate();
    }

    public BusinessUnits getBusinessUnits(String templateName) {
        Optional<BusinessUnits> optionalBusinessUnits=businessUnitsRepository.findByTemplateName(templateName);
        BusinessUnits businessUnits;
        businessUnits = optionalBusinessUnits.orElse(null);
        return businessUnits;
    }

    public List<BusinessUnits> findAll() {
        return businessUnitsRepository.findAll();
    }

    public List<L2Data> getL2Data() {
        return l2DataRepository.findAll();
    }

    public List<L2Data> getL2Data(String statusType) {
        return l2DataRepository.findByStatusType(statusType);
    }

    public List<Object[]> getL2ParentTitlesData(String l2_sid) {
        return l2DataRepository.findL2KeyL1Titles(l2_sid);
    }

    public List<Object[]> getL3TitlesData() {
        return l3DataRepository.findL2KeyL3Titles();
    }

    public List<L3Data> getL3BasedOnL2Key(String l2Sid) {
        return l3DataRepository.findByL2Sid(l2Sid);
    }

    public List<L3Data> getL3Data(String statusType) {
        return l3DataRepository.findByStatusType(statusType);
    }


    public List<Object[]> getL3ParentTitlesData(String l3_ssid) {
        return l3DataRepository.findL3KeyL2Titles(l3_ssid);
    }
    public List<Object[]> getL4TitlesData() {
        return l3L4DataRepository.findL3KeyL4Titles();
    }

    public TechnicalServiceTemplate getTechnicalServiceTemplate(String templateName) {
        Optional<TechnicalServiceTemplate> optionalTechnicalServiceTemplate=technicalServiceTemplateRepository.findByTemplateName(templateName);
        TechnicalServiceTemplate technicalServiceTemplate = optionalTechnicalServiceTemplate.orElse(null);
        return technicalServiceTemplate;
    }

    public List<L4Data> getL4Data() {
        return l4DataRepository.findAll();
    }

    public List<L4Data> getL4Data(String statusType) {
        return l4DataRepository.findByStatusType(statusType);
    }

    public List<Object[]> getL4ParentTitlesData(String l4Id) {
        return l3L4DataRepository.findL4KeyL3Titles(l4Id);
    }

    public List<Object[]> getL5TitlesData() {
        return l4L5DataRepository.findL4KeyL5Titles();
    }

    public List<L5Data> getL5Data() {
        return l5DataRepository.findAll();
    }

    public List<L5Data> getL5Data(String statusType) {
        return l5DataRepository.findByStatusType(statusType);
    }

    public List<Object[]> getL5ParentTitlesData(String l5_cid) {
        return l4L5DataRepository.findL5KeyL4Titles(l5_cid);
    }
    public List<Object[]> getL6TitlesData() {
        return l5L6DataRepository.findL5KeyL6Titles();
    }

    public List<L6Data> getL6Data() {
        return l6DataRepository.findAll();
    }

    public List<L6Data> getL6Data(String statusType) {
        return l6DataRepository.findByStatusType(statusType);
    }

    public List<Object[]> getL6ParentTitlesData(String l6_cid) {
        return l5L6DataRepository.findL6KeyL5Titles(l6_cid);
    }

}
