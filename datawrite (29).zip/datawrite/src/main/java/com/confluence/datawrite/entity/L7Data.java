package com.confluence.datawrite.entity;

import lombok.Data;

@Data
public class L7Data {
    // id
    private Long id;
    // data_classification
    private String dataClassification;
    // data_owners
    private String dataOwners;
    // data_management
    private String dataManagement;
    // security_model
    private String securityModel;
    // data_locality
    private String dataLocality;
    // ciid
    private String ciid;
    // backup_archive
    private String backupArchive;
    // regulatory_or_sox_compliance_req
    private String regulatoryOrSoxComplianceReq;
    // architecture_links
    private String architectureLinks;


}
