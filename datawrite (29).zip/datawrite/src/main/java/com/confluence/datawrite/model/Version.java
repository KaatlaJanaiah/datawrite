package com.confluence.datawrite.model;

import lombok.Data;

@Data
public class Version {
    Integer number=1;
}
