package com.confluence.datawrite.processor;

import com.confluence.datawrite.model.*;
import com.confluence.datawrite.restapi.ConfluenceRestClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.util.StringUtil;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ObjectDataUtil {
    @Autowired
    DataUtil dataUtil;

    @Autowired
    ConfluenceRestClient confluenceRestClient;

    ObjectMapper mapper = new ObjectMapper();

    private Map<String,String> businessUnits;
    
    private Map<String,String> baseTemplateMap;

    private Map<String,String> tsMap;

    private String getConfluenceDataWithTitle(String title) {
        String pageId="";
        try {
            ResponseEntity<String> responseEntity = confluenceRestClient.getPageWithTitleFromConfluencePage(title);
            ObjectMapper mapper = new ObjectMapper();
            Page pageData = mapper.readValue(responseEntity.getBody(), Page.class);

            Map m = (Map) pageData.getResults().get(0);
            System.out.println(title + " pageId => " + m.get("id"));
            pageId=""+m.get("id");
        } catch (Exception e) {
            System.err.println(e.getMessage());
        }
        return pageId;
    }

    private String getConfluenceCurrentVersion(ResponseEntity<String> responseEntity) throws JsonProcessingException {
        ObjectMapper mapper = new ObjectMapper();
        Page pageData=mapper.readValue(responseEntity.getBody(),Page.class);
        Map m=(Map)pageData.getResults().get(0);
        System.out.println("Version number  => "+m.get("number"));
        return ""+m.get("number");
    }

    public void setBusinessUnits(Map<String,String> businessUnits) {
        this.businessUnits=businessUnits;
    }

    public Map<String,String> getBusinessUnits() {
        return this.businessUnits;
    }

    public void setBaseTemplateMap(Map<String,String> baseTemplateMap) {
        this.baseTemplateMap=baseTemplateMap;
    }

    public Map<String,String> getBaseTemplateMap() {
        return this.baseTemplateMap;
    }

    public void setTSMap(Map<String,String> tsMap) {
        this.tsMap=tsMap;
    }

    public Map<String,String> getTSMap() {
        return this.tsMap;
    }

    public String excelIterateToConfluence(RequestDTO requestDTO) {
        return confluenceConnect(requestDTO);
    }

    private String confluenceConnect(RequestDTO requestDTO)  {
        String resBody="";
        String parentID="";
        String jsonString ="";
        try {
            jsonString = objectToJson(requestDTO);
            resBody= confluenceRestClient.writeOnConfluencePageReturnResponse(jsonString).getBody();
            parentID=dataUtil.getParentID(resBody);
            // System.out.println("parentID==> "+parentID);
        } catch (Exception exception) {
            parentID=this.dataUtil.failedMsg();
            System.err.println("Unable to create this page: "+requestDTO.getTitle()+"====>"+exception.getMessage());
            System.out.println("jsonString => " + jsonString);

        }
        return parentID;
    }

    private String objectToJson(RequestDTO requestDTO)  {
        String jsonString ="";
        try {
            jsonString = mapper.writeValueAsString(requestDTO);
        } catch (Exception exception) {
            System.out.println(" <== Not Formed Json===> " +exception.getMessage());
            System.out.println(" <== jsonString===> " +jsonString);
        }
        return jsonString;
    }

    public String setBaseTemplateRequestModel(RequestModel requestModel) {
        RequestDTO requestDTO = requestModel.getRequestDTO();
        String parentID = confluenceConnect(requestDTO);
        return parentID;
    }

    public String getPageIdBasedOnTitle(String title) {
        return getConfluenceDataWithTitle(title);
    }

    public void deleteConfluencePageBasedOnPageID(String pageId) {
        confluenceRestClient.deletePageListFromConfluencePage(pageId);
    }

    public void lastChildRequestModel(List<RequestModel> requestModels) {
        int passCount=0;
        int failCount=0;
        try {
            for (RequestModel requestModel : requestModels) {
                RequestDTO requestDTO = requestModel.getRequestDTO();
                /*if (requestModel.isChild())
                    dataUtil.setLinkGraph(requestDTO.getTitle(),requestDTO.getBody());*/
                String parentID = confluenceConnect(requestDTO);
                if (StringUtil.isNotBlank(parentID)) {
                    if (parentID.equals(this.dataUtil.failedMsg())) {
                        failCount++;
                    } else {
                        passCount++;
                        requestDTO.setId(parentID);
                    }
                }
            }
        } catch (Exception e) {
            failCount++;
            System.err.println("lastChildRequestModel==> "+e.getMessage());
        }
        System.out.println("Success Count==>"+passCount);
        System.out.println("Fail Count==>"+failCount);
    }

    /*public void updateChildRequestModel(List<RequestModel> requestModels) {
        System.out.println("updateChildRequestModel");
        int passCount=0;
        int failCount=0;
        try {
            for (RequestModel requestModel : requestModels) {
                RequestDTO requestDTO = requestModel.getRequestDTO();
                requestDTO.setId(requestModel.getPageId());
                Version version=getVersionNum(requestModel.getPageId());
                requestDTO.setVersion(version);
                // confluenceRestClient.getPageContentFromConfluencePage(requestModel.getPageId());
                if (requestModel.isChild())
                    dataUtil.setLinkGraph(requestDTO.getTitle(),requestDTO.getBody());
                updateConfluencePage(requestDTO);
            }
        } catch (Exception e) {
            e.printStackTrace();
            failCount++;
            System.err.println("updateChildRequestModel==> "+e.getMessage());
        }
        System.out.println("Success Count==>"+passCount);
        System.out.println("Fail Count==>"+failCount);
    }*/

    public Map<String,String> parentPageIDsRequestModel(List<RequestModel> requestModels) {
        Map<String,String> map=new HashMap<>();
        try {
            for(RequestModel requestModel:requestModels) {
                map.put(requestModel.getKeyValue(),requestModel.getRequestDTO().getId());
            }
        } catch (Exception e) {
            System.err.println("parentPageIDsRequestModel==> "+e.getMessage());
        }
        return map;
    }

    public List<String> getBaseTemplateNames() {
        List<String> baseTemplateList=new ArrayList<>();
        baseTemplateList.add(dataUtil.config.getIbs_PageKey());
        baseTemplateList.add(dataUtil.config.getBs_PageKey());
        baseTemplateList.add(dataUtil.config.getTs_PageKey());
        return baseTemplateList;
    }

    public List<String> getTSBaseTemplateNames() {
        List<String> tsTemplates=new ArrayList<>();
        tsTemplates.add(dataUtil.config.getTs_L4_PageKey());
        tsTemplates.add(dataUtil.config.getTs_L5_PageKey());
        tsTemplates.add(dataUtil.config.getTs_L6_PageKey());
        return tsTemplates;
    }

    public Version getVersionNum(String pageId) {
        Version version=null;
        try {
            ResponseEntity<String> responseEntity = confluenceRestClient.getPageVersionFromConfluencePage(pageId);
            String number = getConfluenceCurrentVersion(responseEntity);
            version=new Version();
            version.setNumber(Integer.parseInt(number) + 1);
        } catch (Exception exception) {
            System.err.println(exception.getMessage());
        }
        return version;
    }

    public ConfluenceData makeStorageFromConfluenceResponse(String pageId) {
        ConfluenceData confluenceData=new ConfluenceData();
        try {
            System.out.println("==makeStorageFromConfluenceResponse==");
            ResponseEntity<String> responseEntity=confluenceRestClient.getPageContentFromConfluencePage(pageId);
            confluenceData=fromConfluenceData(responseEntity.getBody());
        } catch (Exception e) {
            System.err.println("makeStorageFromConfluenceResponse : "+e.getMessage());
        }
        return confluenceData;
    }

    public String getAncestorsFromConfluenceResponse(String pageId) {
        String ancestor="";
        try {
            System.out.println("==getAncestorsFromConfluenceResponse==");
            ResponseEntity<String> responseEntity=confluenceRestClient.getAncestorsFromConfluencePage(pageId);
            ConfluenceData confluenceData=fromConfluenceData(responseEntity.getBody());
            Map m=(Map)confluenceData.getAncestors().get(confluenceData.getAncestors().size()-1);
            System.out.println("Ancestors number  => "+m.get("id"));
            ancestor= ""+m.get("id");
        } catch (Exception e) {
            System.err.println("getAncestorsFromConfluenceResponse : "+e.getMessage());
        }
        return ancestor;
    }

    public RequestDTO getUpdatedObjectFromConfluenceData(String title) {
        RequestDTO requestDTO=null;
        String pageId=getPageIdBasedOnTitle(title);
        if (StringUtil.isNotBlank(pageId)) {
            Version version = getVersionNum(pageId);
            String ancestor = getAncestorsFromConfluenceResponse(pageId);
            ConfluenceData confluenceData = makeStorageFromConfluenceResponse(pageId);
            System.out.println("final object: "+confluenceData);
            requestDTO = dataUtil.getBasicRequestDTO(title);
            requestDTO.setId(pageId);
            requestDTO.setVersion(version);
            requestDTO.setAncestors(dataUtil.getListAncestor(ancestor));
            requestDTO.setType(confluenceData.getType());
            requestDTO.setBody(dataUtil.getBody(confluenceData.getBody().getStorage().getValue()));
        }
        return requestDTO;
    }

    private ConfluenceData fromConfluenceData(String body) {
            ConfluenceData confluenceData=new ConfluenceData();
            try {
                System.out.println("==fromConfluenceData==");
                confluenceData=mapper.readValue(body,ConfluenceData.class);
            } catch (Exception e) {
                System.err.println("fromConfluenceData : "+e.getMessage());
            }
            return confluenceData;

    }

    public String getChildLinksFromStorageValue(String title,String value) {
        // String startRelax="<ac:structured-macro ac:name=\"panel\" ac:macro-id=\"links_"+title+"\">";
        String startRelax="<ul><li><p><ac:link>";
        String endRelax="</ac:link></p></li>";
        String subStr ="";
        int startIndex=value.lastIndexOf(startRelax);
        int endIndex=value.lastIndexOf(endRelax+"</ul>");
        if (startIndex > -1 && endIndex>-1 ) {
            subStr = value.substring(startIndex+4, endIndex);
            subStr = subStr + endRelax;
        }
        System.out.println("links subString==>" + subStr);
        return subStr;
    }

    public String removeChildLinkStorageValue(String childLinks, String removeTitle) {
        // <ac:structured-macro ac:name="panel" ac:macro-id="table_1 - Ailyn">

        String endRelax="</ac:link></p></li>";
        String res = "";
        String subSub;
        String split[] = childLinks.split(endRelax);
        for (String sp : split) {
            subSub = sp + endRelax;
            if (!subSub.contains(removeTitle)) {
                res = res + subSub;
            }
        }
        System.out.println("removed child link result : " + res);
        return res;
    }

    public String appendChildLinks(String childLinks, String childTitle) {
        childLinks = childLinks + dataUtil.buildLI(dataUtil.getHyperLink(childTitle));
        return childLinks;
    }

    public void updateConfluencePage(RequestDTO requestDTO) {
        String jsonString=objectToJson(requestDTO);
        if (StringUtil.isNotBlank(jsonString)) {
            confluenceRestClient.updatePageFromConfluencePage(requestDTO.getId(),jsonString);
        }
    }

    public List<String> getListOfPageIdsForChildConfluenceResponse(String body)  {
        List<String> pageIdList=new ArrayList<>();
        try {
            Page parentID=mapper.readValue(body,Page.class);
            for (int i=0;i<parentID.getSize();i++) {
                Map m=(Map)parentID.getResults().get(i);
                pageIdList.add(""+m.get("id"));
            }
        } catch (Exception e) {
            System.err.println("getListOfPageIdsFromConfluence : "+e.getMessage());
        }
        return pageIdList;
    }

    public List<String> getListOfPageIdsFromConfluenceResponse(String body)  {
        List<String> pageIdList=new ArrayList<>();
        try {
            ListPageIDs parentID=mapper.readValue(body,ListPageIDs.class);
            for (int i=0;i<parentID.getPage().getSize();i++) {
                Map m=(Map)parentID.getPage().getResults().get(i);
                pageIdList.add(""+m.get("id"));
            }
        } catch (Exception e) {
            System.err.println("getListOfPageIdsFromConfluence : "+e.getMessage());
        }
        return pageIdList;
    }

    public void l2DeleteChildPages(String parentId) {
        ResponseEntity<String> responseEntity=confluenceRestClient.getChildPageIdsFromConfluencePage(parentId);
        List<String> pageIds=getListOfPageIdsForChildConfluenceResponse(responseEntity.getBody());
        deleteListOfPages(pageIds);
    }

    public void processDeletePages(Integer start, Integer limit) {
        ResponseEntity<String> responseEntity=confluenceRestClient.getPageListFromConfluencePage(start,limit);
        List<String> pageIds=getListOfPageIdsFromConfluenceResponse(responseEntity.getBody());
        deleteListOfPages(pageIds);
    }

    public void deleteListOfPages(List<String> pageIds) {
        if (pageIds.size() > 0) {
            for (String pageId: pageIds) {
                deleteConfluencePageBasedOnPageID(pageId);
            }
        }

    }

    public String setConfluenceTitle(String titleOne, String titleTwo) {
        return titleOne != null && titleTwo != null?validateString(titleOne)+" - "+validateString(titleTwo):"";
    }

    public Map<String,String> getChildLinks(List<Object[]> childTitles) {
        Map<String, String> childTitlesLinks=new HashMap<>();
        String childTitle;
        String childLinks = "";
        String key;
        for (Object[] obj: childTitles) {
            key=""+obj[0];
            childTitle=""+obj[1];
            childLinks = childTitlesLinks.get(key) != null ? childTitlesLinks.get(key) : "";
            childLinks = appendChildLinks(childLinks, childTitle);
            childTitlesLinks.put(key, childLinks);
        }
        return childTitlesLinks;
    }



    public List<String> parseObjectArrayListToStringList(List<Object[]> singleValueObjArray) {
        List<String> values=new ArrayList<>();
        for (Object[] obj: singleValueObjArray) {
            values.add(""+obj[0]);
        }
        return values;
    }

    public String validateString(String value) {
        String res=value != null? value.trim().equals("#N/A")?"":value.trim().replace(" & "," and ")
                .replace("&","and").replace(".0",""):"";
        return res;
    }

    /**  delete functions */

    public String getTitlePageId(String title) {
        String pageId ="";
        if (StringUtil.isNotBlank(title)) {
            try {
                pageId = getPageIdBasedOnTitle(title);
            } catch (Exception e) {
                System.err.println(e.getMessage());
            }
        }
        return pageId;
    }


    public void deletePage(String pageId, String title, List<Object[]> parentTitleList) {
        if (parentTitleList!=null && !parentTitleList.isEmpty()) {
            removeChildLinkFromParentPage(title, parentTitleList);
        }
        deleteConfluencePageBasedOnPageID(pageId);
    }

    public void removeChildLinkFromParentPage(String childTitle, List<Object[]> parentTitleList) {
        List<String> titles=parseObjectArrayListToStringList(parentTitleList);
        updateParentBeforeChildDelete(titles,childTitle);
    }

    public void updateParentBeforeChildDelete(List<String> parentTitles, String childTitle) {
        RequestDTO requestDTO=null;
        if (parentTitles != null && !parentTitles.isEmpty()) {
            for (String title: parentTitles) {
                requestDTO=getUpdatedObjectFromConfluenceData(title);
                if (requestDTO != null) {
                    String storageValue = requestDTO.getBody().getStorage().getValue();
                    String confluenceChildLinks = getChildLinksFromStorageValue(title,storageValue);
                    String removedChildLinks = removeChildLinkStorageValue(confluenceChildLinks, childTitle);
                    storageValue=storageValue.replace(confluenceChildLinks,removedChildLinks);
                    System.out.println("final storageValue => "+storageValue);
                    requestDTO.setBody(dataUtil.getBody(storageValue));
                    updateConfluencePage(requestDTO);
                }
            }
        }
    }

    public void updateTableAndLinksData(RequestDTO requestDTO, String tableData, List<String> newChildLinks) {
        if (tableData != null && !tableData.isEmpty() && requestDTO != null) {
            if (requestDTO != null) {
                String storageValue = requestDTO.getBody().getStorage().getValue();
                String storageTableData=getTableFromStorageValue(storageValue);
                storageValue=storageValue.replace(storageTableData,tableData);
                String confluenceChildLinks = getChildLinksFromStorageValue(requestDTO.getTitle(),storageValue);
                String finalLinks=makeFinalLinksForUpdate(newChildLinks, confluenceChildLinks);
                storageValue=storageValue.replace(confluenceChildLinks,finalLinks);
                requestDTO.setBody(dataUtil.getBody(storageValue));
                updateConfluencePage(requestDTO);
            }
        }
    }

    public String getTableFromStorageValue(String value) {
        String startRelax="<div style=\"height: 100.0%;\"><div><div style=\"height: 100.0%;\"><div><div><table><tbody>";
        String endRelax="</tbody></table></div></div>";
        String upendRelax="</tbody></table></div>";
        String removeStr="<div style=\"height: 100.0%;\"><div><div style=\"height: 100.0%;\"><div>";
        String subStr ="";
        int startIndex=value.indexOf(startRelax);
        int endIndex=value.indexOf(endRelax);
        if (startIndex > -1 && endIndex>-1 ) {
            subStr = value.substring(startIndex, endIndex);
            subStr = subStr.replace(removeStr,"") + upendRelax;
        }
        System.out.println("tableData subString==>" + subStr);
        return subStr;
    }

    public Map<String,List<String>> getChildList(List<Object[]> childTitles) {
        Map<String, List<String>> childTitlesLinks=new HashMap<>();
        String childTitle;
        List<String> childLinks = null;
        String key;
        for (Object[] obj: childTitles) {
            key=""+obj[0];
            childTitle=""+obj[1];
            childLinks = childTitlesLinks.get(key) != null ? childTitlesLinks.get(key) : new ArrayList<>();
            childLinks.add(childTitle);
            childTitlesLinks.put(key, childLinks);
        }
        return childTitlesLinks;
    }

    public String makeFinalLinksForUpdate(List<String> childTitles, String storageChild) {
        String ulData = storageChild;
        for (String childTitle: childTitles) {
            if (!ulData.contains(childTitle)) {
                ulData =ulData + dataUtil.buildLI(dataUtil.getHyperLink(childTitle));
            }
        }
        return ulData;
    }

}
