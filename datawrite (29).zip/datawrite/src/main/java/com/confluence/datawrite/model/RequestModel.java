package com.confluence.datawrite.model;

import lombok.Data;

@Data
public class RequestModel {
    String keyValue;
    String parentLinkValue;
    RequestDTO requestDTO;
    String outGoingLink;
    String inGoingLink;
    String pageId;
    String statusType;
    boolean child=true;
}
