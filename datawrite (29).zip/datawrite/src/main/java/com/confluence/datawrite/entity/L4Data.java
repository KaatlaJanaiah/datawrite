package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "l4_data")
public class L4Data {


    @Id
    private Long id;
    @Column(name="ssid")
    private String sSid;
    @Column(name="l3_service_name")
    private String l3ServiceName;
    @Column(name="l4_software_licence_external_id")
    private String softwareLicenceExternalId;
    @Column(name="l4_application_name")
    private String applicationName;
    @Column(name="l4_ccid")
    private String cCid;
    @Column(name="l4_ccid_name")
    private String cCidName;
    @Column(name="business_domain")
    private String businessDomain;
    @Column(name="metamodel")
    private String metamodel;
    @Column(name="application_owner")
    private String applicationOwner;
    @Column(name="application_status")
    private String applicationStatus;
    @Column(name="ciid")
    private String ciid;
    @Column(name="application_functions")
    private String applicationFunctions;
    @Column(name="criticality_or_cat_of_service")
    private String criticalityOrCatOfService;
    @Column(name="details")
    private String details;
    @Column(name="regulatory_or_sox_compliance")
    private String regulatoryOrSoxCompliance;
    @Column(name="assignment_group")
    private String assignmentGroup;
    @Column(name="support_groups")
    private String supportGroups;
    @Column(name="provider")
    private String provider;

    @Column(name="application_type")
    private String applicationType;
    @Column(name="predecessors")
    private String predecessors;
    @Column(name="obsolescence_score")
    private String obsolescenceScore;
    @Column(name="architecture_links")
    private String architectureLinks;

    @Column(name = "status_type")
    private String statusType;

    @Transient
    private String l5TitleList;

    @Transient
    private String pageId;

}
