package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.L3Data;
import com.confluence.datawrite.entity.L5Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface L5DataRepository extends JpaRepository<L5Data, Long> {

    public static final String FIND_L3Titles = "SELECT l2_sid, concat(l3_ssid, ' - ', l3_name) FROM l3_data where l2_sid is not null and l2_sid != ''";

    @Query(value = FIND_L3Titles, nativeQuery = true)
    public List<Object[]> findL2KeyL3Titles();

    List<L5Data> findByStatusType(String statusType);
}
