package com.confluence.datawrite.processor;

import com.confluence.datawrite.config.Config;
import com.confluence.datawrite.model.*;
import com.confluence.datawrite.restapi.ConfluenceRestClient;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.poi.util.StringUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ExcelDataUtil {
    @Autowired
    Config config;

    @Autowired
    DataUtil dataUtil;

    @Autowired
    ObjectDataUtil objectDataUtil;

    public XSSFWorkbook getWorkbook(String filePath) throws IOException {
        FileInputStream fileInputStream=new FileInputStream(new File(filePath));
        XSSFWorkbook workbook=new XSSFWorkbook(fileInputStream);
        return workbook;
    }

    public List<String> getRowCellsData(XSSFRow xssfRow) {
        List<String> rowData=new ArrayList<>();
        for(int i=0;i<xssfRow.getPhysicalNumberOfCells();i++) {
            rowData.add(xssfRow.getCell(i)+"");
        }
        return rowData;
    }

    public String getXSSCellDataToString(XSSFCell xssfCell) {
        String res=xssfCell != null? xssfCell.toString().trim().equals("#N/A")?"":xssfCell.toString().trim()
                .replace(" & "," and ").replace("&","and").replace(".0",""):"";
        return res;
    }

    public Map<String,String> getKeyColValues(XSSFSheet xssfSheet, Integer keyColIndex, int cellCount) {
        Map<String,String> keyColData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String val;
            for (int i=1;i<xssfSheet.getPhysicalNumberOfRows();i++) {
                xssfRow=xssfSheet.getRow(i);
                if (keyColIndex<cellCount) {
                    val = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                    keyColData.put(val, val);
                }
            }
        } catch (Exception e) {
            System.out.println("getKeyColValues=>"+e.getMessage());
        }
        return keyColData;
    }

    public List<RequestModel> getBaseRequestDTO(XSSFSheet xssfSheet, Integer titleIndex1,
                                                Integer titleIndex2, List<String> headers, String parentID) {
        List<RequestModel> requestDTOList=new ArrayList<>();
        try {
            XSSFRow xssfRow;
            int cellCount;
            String titleOne="";
            String titleTwo="";
            String titleName="";
            StringBuffer trData=new StringBuffer();
            String tableData="";
            int rowCount=xssfSheet.getPhysicalNumberOfRows();
            for (int i=1;i<rowCount;i++) {
                titleName="";
                xssfRow=xssfSheet.getRow(i);
                cellCount=headers.size();
                if (titleIndex1<cellCount) {
                    titleOne=getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    if (titleIndex2 != null && titleIndex2<cellCount) {
                        titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                    }
                    titleName = !titleOne.isEmpty()?!titleTwo.isEmpty()?titleOne+" - "+titleTwo:titleOne:"";

                }
                if (!titleName.isEmpty()) {
                    trData=new StringBuffer();
                    for (int j=2;j<cellCount;j++) {
                        String val=getXSSCellDataToString(xssfRow.getCell(j));
                        trData.append(dataUtil.buildTR(dataUtil.buildTH(headers.get(j))
                                + dataUtil.buildTD(val)));
                    }
                    tableData=dataUtil.layOutTemplate(titleName,dataUtil.buildTable(trData));
                    RequestDTO requestDTO=dataUtil.getBasicRequestDTO(titleName);
                    requestDTO.setBody(dataUtil.getBody(tableData));
                    if (parentID != null && !parentID.isEmpty()) {
                        requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
                    }
                    RequestModel requestModel=new RequestModel();
                    requestModel.setRequestDTO(requestDTO);
                    requestModel.setKeyValue(titleOne);
                    // System.out.println("base set up parentLinkTitle==>"+parentLinkTitle);
                    // requestModel.setParentLinkValue(parentLinkTitle);
                    requestDTOList.add(requestModel);
                }
            }
        } catch (Exception e) {
            System.err.println("getBaseRequestDTO=>"+e.getMessage());
        }
        return requestDTOList;
    }

    public void setBusinessUnitMaps(XSSFSheet xssfSheet, Integer titleIndex1, Map<String,String> businessUnits) {
        try {
            XSSFRow xssfRow;
            String titleOne="";
            String titleName="";
            int rowCount=xssfSheet.getPhysicalNumberOfRows();
            for (int i=1;i<rowCount;i++) {
                titleName="";
                xssfRow=xssfSheet.getRow(i);
                if (titleIndex1==2 || titleIndex1==3) {
                    titleOne=getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    titleName = !titleOne.isEmpty()?titleOne:"";
                }
                if (!titleName.isEmpty()) {
                    businessUnits.put(titleName,titleName);
                }
            }
        } catch (Exception e) {
            System.err.println("businessUnits=>"+e.getMessage());
        }
    }

    public List<RequestModel> createBusinessUnitRequestModels(Map<String, String > businessUnits, String parentID) {
        List<RequestModel> requestDTOList=new ArrayList<>();
        try {
            for (String titleName:businessUnits.keySet()) {
                RequestDTO requestDTO = dataUtil.getBasicRequestDTO(titleName);
                requestDTO.setBody(dataUtil.getBody(titleName));
                if (parentID != null && !parentID.isEmpty()) {
                    requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
                }
                RequestModel requestModel = new RequestModel();
                requestModel.setRequestDTO(requestDTO);
                requestModel.setKeyValue(titleName);
                requestDTOList.add(requestModel);
            }
        } catch (Exception e) {
            System.err.println("createBusinessUnitRequestModels=>"+e.getMessage());
        }
        return requestDTOList;
    }

    public Map<String,String> getChildKeyColValues(XSSFSheet xssfSheet, Integer keyColIndex,
                                                   Map<String,String> parentMapData, Integer mapColIndex, int cellCount) {
        Map<String,String> keyColData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String val;
            String mapVal;
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);
                if (keyColIndex < cellCount && mapColIndex < cellCount && cellCount >= 2) {
                    mapVal = getXSSCellDataToString(xssfRow.getCell(mapColIndex));
                    String matchVal = parentMapData.get(mapVal);
                    if (matchVal != null && !matchVal.isEmpty()) {
                        val = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                        keyColData.put(val, val);
                    }
                }
            }
        }  catch (Exception e) {
            System.err.println("getChildKeyColValues=>"+e.getMessage());
        }
        return keyColData;
    }

    public Map<String,String> getNonChildKeyColValues(XSSFSheet xssfSheet, Integer keyColIndex,
                                                   Integer mapColIndex, int cellCount) {
        Map<String,String> keyColData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String val;
            String mapVal;
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);
                if (keyColIndex < cellCount && mapColIndex < cellCount && cellCount >= 2) {
                    val = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                    keyColData.put(val, val);
                }
            }
        }  catch (Exception e) {
            System.err.println("getNonChildKeyColValues=>"+e.getMessage());
        }
        return keyColData;
    }

    public Map<String,String> getTitleValues(XSSFSheet xssfSheet, Map<String,String> mapData,
                                             Integer keyColIndex,Integer titleIndex1, Integer titleIndex2, int cellCount) {
        Map<String,String> keyTitleData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String val;
            String mapVal;
            String titleOne="";
            String titleTwo="";
            String titleName;
            String key;
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);
                if (titleIndex1 < cellCount) {
                    mapVal = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                    key = mapData.get(mapVal);
                    if (key != null && !key.isEmpty()) {
                        titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                        if (titleIndex2 != null && titleIndex2 < cellCount)
                            titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                        titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : titleOne : "";
                        if (!titleName.isEmpty()) {
                            keyTitleData.put(key,titleName);
                        }
                    }
                }
            }
        }  catch (Exception e) {
            System.err.println("getTitleValues==> "+e.getMessage());
        }
        return keyTitleData;
    }

    public Map<String,String> getTitleLinkValue(XSSFSheet xssfSheet, Map<String,String> mapData, Integer keyColIndex,
                                                Integer titleIndex1, Integer titleIndex2, int cellCount) {
        Map<String,String> sheetMapTitleData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String mapVal;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            String key = "";
            String titleList = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);

                if (keyColIndex < cellCount && titleIndex1 < cellCount && cellCount >= 3) {
                    mapVal = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                    key = mapData.get(mapVal);
                    if (key != null && !key.isEmpty()) {
                        titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                        if (titleIndex2 != null)
                            titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                        titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : "" : "";
                    }
                }
                if (key != null && !titleName.isEmpty()) {
                    titleName = dataUtil.buildLI(dataUtil.getHyperLink(titleName));
                    titleList = sheetMapTitleData.get(key) != null ? sheetMapTitleData.get(key) : "";
                    titleList = titleList + titleName;
                    sheetMapTitleData.put(key, titleList);
                }
            }
        } catch (Exception e) {
            System.err.println("getTitleLinkValue=>"+e.getMessage());
        }
        return sheetMapTitleData;
    }

    public Map<String,String> getListOfLinks(XSSFSheet xssfSheet, Integer keyColIndex,
                                             Integer titleIndex1, Integer titleIndex2, int cellCount) {
        Map<String,String> sheetMapTitleData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            String keyValue = "";
            String titleList = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);

                if (keyColIndex < cellCount && titleIndex1 < cellCount && cellCount >= 3) {
                    keyValue = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                    titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    if (titleIndex2 != null)
                        titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                    titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : "" : "";
                    titleName = dataUtil.buildLI(dataUtil.getHyperLink(titleName));
                    titleList = sheetMapTitleData.get(keyValue) != null ? sheetMapTitleData.get(keyValue) : "";
                    titleList = titleList + titleName;
                    sheetMapTitleData.put(keyValue, titleList);
                }

            }
        } catch (Exception e) {
            System.err.println("getTitleLinkValue=>"+e.getMessage());
        }
        return sheetMapTitleData;
    }

    public Map<String,String> getListOfL4Links(XSSFSheet xssfSheet, Integer parentKeyColIndex,
                                               Integer childKeyColIndex, Map<String,String> l4Titles, int cellCount) {
        Map<String,String> sheetMapTitleData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String titleName = "";
            String keyValue = "";
            String titleList = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);

                if (parentKeyColIndex < cellCount && childKeyColIndex<cellCount && cellCount >= 3) {

                    keyValue = getXSSCellDataToString(xssfRow.getCell(parentKeyColIndex));
                    System.out.println(keyValue);
                    keyValue=keyValue!=null?keyValue:"";
                    System.out.println(keyValue);
                    titleName=l4Titles.get(keyValue)!=null?l4Titles.get(keyValue):"";
                    System.out.println(titleName);
                    String childKey=getXSSCellDataToString(xssfRow.getCell(childKeyColIndex));
                    if (StringUtil.isNotBlank(titleName) && StringUtil.isNotBlank(childKey)) {
                        titleName = dataUtil.buildLI(dataUtil.getHyperLink(titleName));
                        titleList = sheetMapTitleData.get(childKey) != null ? sheetMapTitleData.get(childKey) : "";
                        titleList = titleList + titleName;
                        sheetMapTitleData.put(childKey, titleList);
                    }
                }

            }
        } catch (Exception e) {
            System.err.println("getTitleLinkValue=>"+e.getMessage());
        }
        return sheetMapTitleData;
    }

    public Map<String,String> getL4Titles(XSSFSheet xssfSheet, Integer keyColIndex,
                                          Integer titleIndex1, Integer titleIndex2, int cellCount) {
        Map<String,String> sheetMapTitleData=new HashMap<>();
        try {
            XSSFRow xssfRow;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            String keyValue = "";
            String titleList = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                xssfRow = xssfSheet.getRow(i);

                if (keyColIndex < cellCount && titleIndex1 < cellCount && cellCount >= 3) {
                    keyValue = getXSSCellDataToString(xssfRow.getCell(keyColIndex));
                    titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    if (titleIndex2 != null)
                        titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                    titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : "" : "";
                    // titleName = dataUtil.buildLI(dataUtil.getHyperLink(titleName));

                    sheetMapTitleData.put(keyValue, titleName);
                }

            }
        } catch (Exception e) {
            System.err.println("getTitleLinkValue=>"+e.getMessage());
        }
        return sheetMapTitleData;
    }

    public List<RequestModel> getL1RequestDTO(XSSFSheet xssfSheet,List<String> headers,String parentID,
                                              Integer titleIndex1, Integer titleIndex2, Map<String,String> childLinks,
                                              Integer mapIndex, String parentLinkTitle) {
        List<RequestModel> requestModels=new ArrayList<>();
        try {
            XSSFRow xssfRow;
            Integer cellCount;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            StringBuffer trData = new StringBuffer();
            String tableData = "";
            String ulData = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                titleOne = "";
                titleName = "";
                ulData = "";
                xssfRow = xssfSheet.getRow(i);
                cellCount = headers.size();
                if (titleIndex1 < cellCount) {
                    ulData = childLinks != null ? getULSetData(childLinks, getXSSCellDataToString(xssfRow.getCell(mapIndex))) : "";
                    titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    if (titleIndex2 != null && titleIndex2 < cellCount)
                        titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                    titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : titleOne : "";
                }
                if (!titleName.isEmpty()) {
                    trData = new StringBuffer();
                    for (int j = 3; j < cellCount; j++) {
                        String val = getXSSCellDataToString(xssfRow.getCell(j));
                        trData.append(dataUtil.buildTR(dataUtil.buildTH(headers.get(j))
                                + dataUtil.buildTD(val)));
                    }
                    tableData = dataUtil.buildTable(trData);
                    String businessService = "Business Service";
                    ulData = dataUtil.buildUL(businessService + ulData);
                    RequestDTO requestDTO = dataUtil.getBasicRequestDTO(titleName);
                    requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(titleName,tableData, ulData)));
                    requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
                    RequestModel requestModel = new RequestModel();
                    requestModel.setRequestDTO(requestDTO);
                    requestModel.setKeyValue(titleOne);
                    requestModel.setParentLinkValue(parentLinkTitle);
                    requestModels.add(requestModel);
                }
            }
        } catch (Exception e) {
            System.err.println("getL1RequestDTO==> "+e.getMessage());
        }
        return requestModels;
    }


    public List<RequestModel> getL2RequestModel(XSSFSheet xssfSheet, List<String> headers,Integer titleIndex1, Integer titleIndex2,
                                                Map<String,String> childLinks, String serviceName, Integer businessUnitIndex) {
        List<RequestModel> requestModels=new ArrayList<>();
        try {
            XSSFRow xssfRow;
            Integer k;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            StringBuffer trData = new StringBuffer();
            String tableData = "";
            String ulData = "";
            String parentID = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                titleOne = "";
                titleName = "";
                ulData = "";
                parentID = "";
                xssfRow = xssfSheet.getRow(i);
                k = headers.size();
                if (titleIndex1 < k) {
                    ulData = childLinks != null ? getULSetData(childLinks, getXSSCellDataToString(xssfRow.getCell(titleIndex1))) : "";
                    titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    if (titleIndex2 != null && titleIndex2 < k)
                        titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                    titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : titleOne : "";
                }
                if (!titleName.isEmpty()) {
                    trData = new StringBuffer();
                    for (int j = 3; j < k; j++) {
                        String val = getXSSCellDataToString(xssfRow.getCell(j));
                        trData.append(dataUtil.buildTR(dataUtil.buildTH(headers.get(j))
                                + dataUtil.buildTD(val)));

                    }
                    if (businessUnitIndex!= null && (businessUnitIndex==2 || businessUnitIndex==3)) {
                        String val = getXSSCellDataToString(xssfRow.getCell(businessUnitIndex));
                        if (this.objectDataUtil.getBusinessUnits().get(val) != null) {
                            parentID = this.objectDataUtil.getBusinessUnits().get(val);
                        }
                    }
                    tableData = dataUtil.buildTable(trData);
                    if (serviceName != null && ulData != null) {
                        ulData = dataUtil.buildUL(serviceName + ulData);
                    } else {
                        ulData = "";
                    }
                    RequestDTO requestDTO = dataUtil.getBasicRequestDTO(titleName);
                    requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(titleName,tableData, ulData)));
                    if (parentID != null && !parentID.isEmpty()) {
                        requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
                    }
                    RequestModel requestModel = new RequestModel();
                    requestModel.setRequestDTO(requestDTO);
                    requestModel.setKeyValue(titleOne);
                    requestModels.add(requestModel);
                }
            }
        } catch (Exception e) {
            System.err.println("getL2RequestModel=>"+e.getMessage());
        }
        return requestModels;
    }

    public List<RequestModel> getSheetRequestModel(XSSFSheet xssfSheet, List<String> headers, Integer titleIndex1, Integer titleIndex2,
                                                   String parentID, String childServiceName, Map<String,String> childLinks,  Integer childKeyIndex) { // Map<String,String > parentTitleLinks,Integer parentKeyIndex,
        List<RequestModel> requestModels=new ArrayList<>();
        try {
            XSSFRow xssfRow;
            Integer k;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            StringBuffer trData = new StringBuffer();
            String tableData = "";
            String childTitle = "";
            String parentTitle="";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                childTitle = "";
                parentTitle="";
                xssfRow = xssfSheet.getRow(i);
                k = headers.size();
                if (titleIndex1 < k) {
                    titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                    if (titleIndex2 != null && titleIndex2 < k)
                        titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                    titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : "" : "";

                    if (!titleName.isEmpty()) {
                        RequestDTO requestDTO = dataUtil.getBasicRequestDTO(titleName);
                        trData = new StringBuffer();
                        for (int j = 3; j < k; j++) {
                            String val = getXSSCellDataToString(xssfRow.getCell(j));
                            trData.append(dataUtil.buildTR(dataUtil.buildTH(headers.get(j))
                                    + dataUtil.buildTD(val)));
                        }
                        tableData = dataUtil.buildTable(trData);
                        String value = childKeyIndex!=null?getXSSCellDataToString(xssfRow.getCell(childKeyIndex)):null;
                        childTitle = value != null && childLinks != null ? getULSetData(childLinks, value) : "";
                        if (StringUtil.isNotBlank(childTitle)) {
                            childTitle = dataUtil.buildUL(childServiceName + childTitle);
                        }
                        requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(titleName,parentTitle+tableData, childTitle)));
                        requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
                        RequestModel requestModel = new RequestModel();
                        requestModel.setRequestDTO(requestDTO);
                        requestModel.setKeyValue(titleOne);
                        requestModels.add(requestModel);
                    }
                }
            }
        } catch (Exception e) {
            System.err.println("getChildMapRequestModel==>"+e.getMessage());
        }
        return requestModels;
    }


    public List<RequestModel> parentChildRequestModel(List<RequestModel> requestModels,XSSFSheet xssfSheet, List<String> headers,
                                                      Integer titleIndex1, Integer titleIndex2, Map<String,String> childLinks, String serviceName) throws JsonProcessingException {
        List<RequestModel> finalRequestModels=new ArrayList<>();
        int passCount=0;
        int failCount=0;
        try {
            for (RequestModel requestModel : requestModels) {
                RequestDTO requestDTO = requestModel.getRequestDTO();
                /*if (requestModel.getParentLinkValue() != null && !requestModel.getParentLinkValue().isEmpty())
                    dataUtil.setBody(requestDTO.getBody(),requestModel.getParentLinkValue());*/
                // System.out.println(requestDTO.getBody().getStorage().getValue());
                String parentID =objectDataUtil.excelIterateToConfluence(requestDTO);
                // String parentID="";
                if (StringUtil.isNotBlank(parentID)) {
                    if (parentID.equals(this.dataUtil.failedMsg())) {
                        failCount++;
                    } else {
                        passCount++;
                        List<RequestModel> requestModels1 = singleParentChildMapRequestModel(xssfSheet, headers, parentID, titleIndex1, titleIndex2,
                                childLinks, serviceName, requestModel.getKeyValue(), 0, requestDTO.getTitle());
                        finalRequestModels.addAll(requestModels1);
                    }
                }
            }
        } catch (Exception e) {
            failCount++;
            System.err.println("parentChildRequestModel==>"+e.getMessage());
        }
        System.out.println("Success Count==>"+passCount);
        System.out.println("Fail Count==>"+failCount);
        return finalRequestModels;
    }


    public List<RequestModel> singleParentChildMapRequestModel(XSSFSheet xssfSheet, List<String> headers, String parentID,
                                                               Integer titleIndex1, Integer titleIndex2, Map<String,String> childLinks, String serviceName,
                                                               String parentMapValue, Integer parentMapIndex, String parentLinkTitle ) {
        List<RequestModel> requestModels=new ArrayList<>();
        try {
            XSSFRow xssfRow;
            Integer cellCount;
            String titleOne = "";
            String titleTwo = "";
            String titleName = "";
            StringBuffer trData = new StringBuffer();
            String tableData = "";
            String ulData = "";
            for (int i = 1; i < xssfSheet.getPhysicalNumberOfRows(); i++) {
                titleOne = "";
                titleName = "";
                ulData = "";
                xssfRow = xssfSheet.getRow(i);
                cellCount = headers.size();
                if (titleIndex1 < cellCount) {
                    if (parentMapValue.equals(getXSSCellDataToString(xssfRow.getCell(parentMapIndex)))) {
                        ulData = childLinks != null ? getULSetData(childLinks, getXSSCellDataToString(xssfRow.getCell(titleIndex1))) : "";
                        titleOne = getXSSCellDataToString(xssfRow.getCell(titleIndex1));
                        if (titleIndex2 != null && titleIndex2 < cellCount)
                            titleTwo = getXSSCellDataToString(xssfRow.getCell(titleIndex2));
                        titleName = !titleOne.isEmpty() ? !titleTwo.isEmpty() ? titleOne + " - " + titleTwo : "" : "";
                    }
                }
                if (!titleName.isEmpty()) {
                    RequestDTO requestDTO = dataUtil.getBasicRequestDTO(titleName);
                    trData = new StringBuffer();
                    for (int j = 3; j < cellCount; j++) {
                        String val = getXSSCellDataToString(xssfRow.getCell(j));
                        trData.append(dataUtil.buildTR(dataUtil.buildTH(headers.get(j))
                                + dataUtil.buildTD(val)));
                    }
                    tableData = dataUtil.buildTable(trData);
                    if (!ulData.isEmpty()) {
                        ulData = dataUtil.buildUL(serviceName + ulData);
                    }
                    requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(titleName,tableData, ulData)));
                    requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
                    RequestModel requestModel = new RequestModel();
                    requestModel.setRequestDTO(requestDTO);
                    requestModel.setKeyValue(titleOne);
                    // System.out.println(parentLinkTitle);
                    requestModel.setParentLinkValue(parentLinkTitle);
                    requestModels.add(requestModel);
                }
            }
        } catch (Exception e) {
            System.err.println("singleParentChildMapRequestModel=>"+e.getMessage());
        }
        return requestModels;
    }
    private String getULSetData(Map<String,String> sheetTitles, String key) {
        String ulData;
        String titles=sheetTitles.get(key)!=null?sheetTitles.get(key)+"":"";
        if (!titles.isEmpty()) {
            ulData=dataUtil.buildUL(titles);
        } else {
            ulData="";
        }
        return ulData;
    }


}
