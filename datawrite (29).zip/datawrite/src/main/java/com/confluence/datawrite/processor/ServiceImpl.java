package com.confluence.datawrite.processor;

import com.confluence.datawrite.config.AppConstants;
import com.confluence.datawrite.config.Config;
import com.confluence.datawrite.entity.*;
import com.confluence.datawrite.model.ConfluenceData;
import com.confluence.datawrite.model.RequestDTO;
import com.confluence.datawrite.model.RequestModel;
import com.confluence.datawrite.model.Version;
import com.confluence.datawrite.repository.BaseTemplateRepository;
import com.confluence.datawrite.repository.BusinessUnitsRepository;
import com.confluence.datawrite.repository.TechnicalServiceTemplateRepository;
import com.fasterxml.jackson.core.JsonProcessingException;
import org.apache.poi.util.StringUtil;
import org.apache.poi.xssf.usermodel.XSSFCell;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class ServiceImpl {
    @Autowired
    private DAOImpl daoImpl;

    @Autowired
    private Config config;

    @Autowired
    private DataUtil dataUtil;

    @Autowired
    private ObjectDataUtil objectDataUtil;
    @Autowired
    private BaseTemplateRepository baseTemplateRepository;
    @Autowired
    private BusinessUnitsRepository businessUnitsRepository;
    @Autowired
    private TechnicalServiceTemplateRepository technicalServiceTemplateRepository;

    private Map<String, String> baseTemplateMap;

    private Map<String, String> businessUnitsMap;

    private Map<String, String> tsTemplateMap;

    public void createBasePages() {
        baseTemplateMap=getBaseTemplates();
        businessUnitsMap=getBusinessUnits();
        tsTemplateMap=getTSTemplates();
    }

    public void deleteL1ToL6Pages() {
        deleteL6Data();
        deleteL5Data();
        deleteL4Data();
        deleteL3Data();
        deleteL2Data();
        deleteL1Data();
    }

    public void createL1ToL6Pages() {
        createL1Data();
        createL2Data();
        createL4Data();
        createL5Data();
        createL6Data();
    }

    public void updateL1ToL6Pages() {
        updateL1Data();
        updateL2Data();
        updateL3Data();
        updateL4Data();
        updateL5Data();
        updateL6Data();
    }

    private Map<String, String> getBaseTemplates() {
        createBaseTemplates();
        System.out.println("==createBaseTemplates==");
        List<BaseTemplate> baseTemplateList=baseTemplateRepository.findAll();
        Map<String,String> baseTemplatePagIds=new HashMap<>();
        for (BaseTemplate baseTemplate:baseTemplateList) {
            baseTemplatePagIds.put(baseTemplate.getTemplateName(), baseTemplate.getPageId());
        }
        return baseTemplatePagIds;
    }

    private Map<String ,String> getBusinessUnits() {
        createBusinessUnits();
        List<BusinessUnits> businessUnitsList=daoImpl.findAll();
        Map<String,String> businessUnitPagIds=new HashMap<>();
        for(BusinessUnits businessUnits: businessUnitsList) {
            businessUnitPagIds.put(objectDataUtil.validateString(businessUnits.getTemplateName()), businessUnits.getPageId());
        }
        return businessUnitPagIds;
    }

    private Map<String, String> getTSTemplates() {
        createTSTemplates();
        List<TechnicalServiceTemplate> tsTemplateList=technicalServiceTemplateRepository.findAll();
        Map<String,String> tsTemplatePagIds=new HashMap<>();
        for (TechnicalServiceTemplate tsTemplate:tsTemplateList) {
            tsTemplatePagIds.put(objectDataUtil.validateString(tsTemplate.getTemplateName()), tsTemplate.getPageId());
        }
        return tsTemplatePagIds;
    }

    private void createBaseTemplates() {
        for (String template:objectDataUtil.getBaseTemplateNames()) {
            createBaseParent(template);
        }
    }

    private void createBusinessUnits() {
        List<Object[]> objects=daoImpl.businessUnitsForCreate();
        String key;
        for (Object[] obj: objects) {
            key = "" + obj[0];
            createBusinessUnit(objectDataUtil.validateString(key));
        }
    }

    private void createTSTemplates() {
        for (String template:objectDataUtil.getTSBaseTemplateNames()) {
            createTechnicalService(objectDataUtil.validateString(template));
        }
    }

    private void createBaseParent(String baseTemplateName) {
        BaseTemplate baseTemplate=daoImpl.getBaseTemplate(baseTemplateName);
        System.out.println("createBaseParent");
        if (baseTemplate == null) {
            baseTemplate=new BaseTemplate();
            baseTemplate.setTemplateName(baseTemplateName);
        }
        String basePageID="";
        try {
            basePageID = objectDataUtil.getPageIdBasedOnTitle(baseTemplateName);
        } catch (Exception e) {
            System.err.println("createBusinessUnit confluence error ==> "+e.getMessage());
        }

        if (StringUtil.isBlank(basePageID)) {
            RequestModel requestModel=getParentTemplateRequestModels(baseTemplateName, null);
            basePageID = objectDataUtil.setBaseTemplateRequestModel(requestModel);
        }

        baseTemplate.setPageId(basePageID);
        baseTemplateRepository.save(baseTemplate);
    }

    private void createBusinessUnit(String businessUnitName) {
        BusinessUnits businessUnits=daoImpl.getBusinessUnits(businessUnitName);
        String bsPageId=baseTemplateMap.get(config.getBs_PageKey());

        if (businessUnits == null) {
            businessUnits=new BusinessUnits();
        }
        String bsuPageID="";
        try {
            bsuPageID = objectDataUtil.getPageIdBasedOnTitle(businessUnitName);
        } catch (Exception e) {
            System.err.println("createBusinessUnit confluence error ==> "+e.getMessage());
        }

        if (StringUtil.isBlank(bsuPageID)) {
            RequestModel requestModel=getParentTemplateRequestModels(businessUnitName, bsPageId);
            bsuPageID = objectDataUtil.setBaseTemplateRequestModel(requestModel);
        }
        businessUnits.setTemplateName(businessUnitName);
        businessUnits.setPageId(bsuPageID);
        businessUnitsRepository.save(businessUnits);
    }

    private void createTechnicalService(String subTechnicalServiceName) {
        TechnicalServiceTemplate technicalServiceTemplate=daoImpl.getTechnicalServiceTemplate(subTechnicalServiceName);
        String bsPageId=baseTemplateMap.get(config.getTs_PageKey());
        if (technicalServiceTemplate == null) {
            technicalServiceTemplate=new TechnicalServiceTemplate();
            technicalServiceTemplate.setTemplateName(subTechnicalServiceName);
        }

        String tsPageID="";
        try {
            tsPageID = objectDataUtil.getPageIdBasedOnTitle(subTechnicalServiceName);
        } catch (Exception e) {
            System.err.println("createBusinessUnit confluence error ==> "+e.getMessage());
        }

        if (StringUtil.isBlank(tsPageID)) {
            RequestModel requestModel=getParentTemplateRequestModels(subTechnicalServiceName, bsPageId);
            tsPageID = objectDataUtil.setBaseTemplateRequestModel(requestModel);
        }

        technicalServiceTemplate.setPageId(tsPageID);
        technicalServiceTemplateRepository.save(technicalServiceTemplate);
    }

    private RequestModel getParentTemplateRequestModels(String templateName, String parentID) {
        StringBuffer trData=new StringBuffer();
        String tableData=dataUtil.layOutTemplate(templateName,dataUtil.buildTable(trData));
        RequestDTO requestDTO=dataUtil.getBasicRequestDTO(templateName);
        if (parentID != null && !parentID.isEmpty()) {
            requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
        }
        requestDTO.setBody(dataUtil.getBody(tableData));
        RequestModel requestModel=new RequestModel();
        requestModel.setRequestDTO(requestDTO);
        requestModel.setKeyValue(templateName);
        return requestModel;
    }

    public void testData() {
        String value="<div style=\"height: 100.0%;\"><div><div style=\"height: 100.0%;\"><div><div><table><tbody><tr><th style=\"width: 140.0px;\">Service Owner</th><td>s100</td></tr><tr><th style=\"width: 140.0px;\">Definition</th><td>def1</td></tr><tr><th style=\"width: 140.0px;\">DownTime Impact</th><td>DI1</td></tr><tr><th style=\"width: 140.0px;\">Scope</th><td>Retail</td></tr></tbody></table></div></div><div><table><ul>Business Service<ul><li><p><ac:link><ri:page ri:content-title=\"SID1002 - Corporate Faster Payments\" ri:version-at-save=\"2\" />SID1002 - Corporate Faster Payments</ac:link></p></li><li><p><ac:link><ri:page ri:content-title=\"SID1004 - Retail CHAPS Payments\" ri:version-at-save=\"1\" />SID1004 - Retail CHAPS Payments</ac:link></p></li><li><p><ac:link><ri:page ri:content-title=\"SID1005 - Corporate CHAPS Payments\" ri:version-at-save=\"1\" />SID1005 - Corporate CHAPS Payments</ac:link></p></li></ul></ul></table></div><div style=\"height: 150.0px;overflow: auto;\"><h4 style=\"background-color: rgb(240,240,240);color: rgb(23,43,77);height: 20.0px;width: 100.0px;\"> User Section</h4></div><div><h4 style=\"background-color: #f0f0f0;color: rgb(23,43,77);height: 20.0px;width: 100.0px;\">Graphic</h4></div></div></div><div><ac:structured-macro ac:name=\"linkgraph\" ac:schema-version=\"1\" ac:macro-id=\"4a6ad155-33d9-4b43-95c3-6588fc3f524c\"><ac:parameter ac:name=\"outgoingLinkLevels\">6</ac:parameter><ac:parameter ac:name=\"format\">SVG</ac:parameter><ac:parameter ac:name=\"incomingLinkLevels\">6</ac:parameter><ac:parameter ac:name=\"direction\">LR</ac:parameter></ac:structured-macro></div></div>";
        String linkHeading="Business Service";
        String removeTitle="SID1002 - Corporate Faster Payments";
        String tableData=objectDataUtil.getTableFromStorageValue(value);
        /*String res=objectDataUtil.getChildLinksFromStorageValue(value);
        objectDataUtil.removeChildLinkStorageValue(res,removeTitle);*/


        /*String title="1 - Ailyn";
        // List<Object[]> objects=daoImpl.getL4ParentTitlesData("SLEI11");
        String pageId=objectDataUtil.getTitlePageId(title);
        objectDataUtil.deletePage(pageId,title, null);*/

        // 11763780
        /*objectDataUtil.confluenceRestClient.getChildPageIdsFromConfluencePage("11829443");
        System.out.println(value);*/
    }

    private void deleteL1Data() {
        System.out.println("====Start L1Data Delete====");
        List<L1Data> l1DataList = daoImpl.getL1Data(config.getStatusDelete());
        if (l1DataList!=null)
            System.out.println(l1DataList.size());
        List<String> deleteTitles = new ArrayList<>();
        String title="";
        String pageID="";
        for (L1Data l1Data : l1DataList) {
            title=objectDataUtil.setConfluenceTitle(l1Data.getSr_no() + "", l1Data.getImportant_business_service());
            pageID=objectDataUtil.getTitlePageId(title);
            if (StringUtil.isNotBlank(pageID))
                deleteTitles.add(pageID);
        }
        objectDataUtil.deleteListOfPages(deleteTitles);
        System.out.println("====End L1Data Delete====");
    }

    private void deleteL2Data() {
        System.out.println("=====Start L2Data Delete=====");

        List<L2Data> l2DataList = daoImpl.getL2Data(config.getStatusDelete());
        String title="";
        String pageID="";
        List<Object[]> l1Titles=null;
        for (L2Data l2Data : l2DataList) {
            title=objectDataUtil.setConfluenceTitle(l2Data.getL2Sid(), l2Data.getL2Name());
            pageID=objectDataUtil.getTitlePageId(title);
            if (StringUtil.isNotBlank(pageID)) {
                l1Titles=daoImpl.getL2ParentTitlesData(l2Data.getL2Sid());
                System.out.println(l1Titles);
                // objectDataUtil.l2DeleteChildPages(pageID);
                objectDataUtil.deletePage(pageID,title,l1Titles);
                // deleteTitles.add(pageID);
            }
        }
        // deleteListOfPages(deleteTitles);
        System.out.println("=====End L2Data Delete=====");
    }

    private void deleteL3Data() {
        System.out.println("=====Start L3Data Delete=====");

        List<L3Data> l3DataList = daoImpl.getL3Data(config.getStatusDelete());
        String title="";
        String pageID="";
        List<Object[]> l2Titles;
        for (L3Data l3Data : l3DataList) {
            title=objectDataUtil.setConfluenceTitle(l3Data.getL3Ssid(), l3Data.getL3Name());
            pageID=objectDataUtil.getTitlePageId(title);
            if (StringUtil.isNotBlank(pageID)) {
                l2Titles=daoImpl.getL3ParentTitlesData(l3Data.getL3Ssid());
                objectDataUtil.deletePage(pageID,title,l2Titles);
            }
        }
        System.out.println("=====End L3Data Delete=====");

    }

    private void deleteL4Data() {
        System.out.println("=====Start L4Data Delete=====");

        List<L4Data> l4DataList = daoImpl.getL4Data(config.getStatusDelete());
        String title="";
        String pageID="";
        List<Object[]> l3Titles;
        for (L4Data l4Data : l4DataList) {
            title=objectDataUtil.setConfluenceTitle(l4Data.getSoftwareLicenceExternalId(), l4Data.getApplicationName());
            pageID=objectDataUtil.getTitlePageId(title);
            if (StringUtil.isNotBlank(pageID)) {
                l3Titles=daoImpl.getL4ParentTitlesData(l4Data.getSoftwareLicenceExternalId());
                objectDataUtil.deletePage(pageID,title,l3Titles);
            }
        }
        System.out.println("=====End L4Data Delete=====");
    }

    private void deleteL5Data() {
        System.out.println("=====Start L5Data Delete=====");

        List<L5Data> l5DataList = daoImpl.getL5Data(config.getStatusDelete());
        String title="";
        String pageID="";
        List<Object[]> l4Titles;
        for (L5Data l5Data : l5DataList) {
            title=objectDataUtil.setConfluenceTitle(l5Data.getL5_cid(), l5Data.getL5_cid_name());
            pageID=objectDataUtil.getTitlePageId(title);
            if (StringUtil.isNotBlank(pageID)) {
                l4Titles=daoImpl.getL5ParentTitlesData(l5Data.getL5_cid());
                objectDataUtil.deletePage(pageID,title,l4Titles);
            }
        }
        System.out.println("=====End L5Data Delete=====");

    }

    private void deleteL6Data() {
        System.out.println("=====Start L6Data Delete=====");

        List<L6Data> l6DataList = daoImpl.getL6Data(config.getStatusDelete());
        String title="";
        String pageID="";
        List<Object[]> l5Titles;
        for (L6Data l6Data : l6DataList) {
            title = objectDataUtil.setConfluenceTitle(l6Data.getL6_cid(), l6Data.getL6_cid_name());
            pageID=objectDataUtil.getTitlePageId(title);
            if (StringUtil.isNotBlank(pageID)) {
                l5Titles=daoImpl.getL6ParentTitlesData(l6Data.getL6_cid());
                objectDataUtil.deletePage(pageID,title,l5Titles);
            }
        }
        System.out.println("=====End L6Data Delete=====");
    }

    /** Start update L1 to L6 */

    private void updateL1Data() {
        System.out.println("== Start L1Data Update==");
        String l1ParentID=baseTemplateMap.get(config.getIbs_PageKey());
        if (StringUtil.isNotBlank(l1ParentID)) {
            List<L1Data> l1DataList = daoImpl.getL1Data(config.getStatusUpdate());
            System.out.println(l1DataList);
            List<Object[]> l2Titles = daoImpl.getL2TitlesData();

            Map<String, List<String>> l1KeyL2TitlesMap = objectDataUtil.getChildList(l2Titles);

            String title="";
            String tableData="";
            List<String> childTitles=null;
            for (L1Data l1Data : l1DataList) {
                title=objectDataUtil.setConfluenceTitle(l1Data.getSr_no() + "", l1Data.getImportant_business_service());
                tableData=getL1TableData(l1Data);
                childTitles=l1KeyL2TitlesMap.get(l1Data.getIbs_l1());
                RequestDTO requestDTO=objectDataUtil.getUpdatedObjectFromConfluenceData(title);
                objectDataUtil.updateTableAndLinksData(requestDTO, tableData,childTitles);
            }

        }
        System.out.println("== End L1Data Update==");
    }

    private void updateL2Data() {
        System.out.println("=====Start L2Data update=====");

        List<L2Data> l2DataList = daoImpl.getL2Data(config.getStatusUpdate());
        System.out.println(l2DataList);

        List<Object[]> l3Titles = daoImpl.getL3TitlesData();

        Map<String, List<String>> l2KeyL3TitlesMap = objectDataUtil.getChildList(l3Titles);
        System.out.println(l2KeyL3TitlesMap);
        String title="";
        String tableData="";
        List<String> childTitles=null;
        for (L2Data l2Data : l2DataList) {
            // l2Data.setL3TitleList(l2KeyL3TitlesMap.get(l2Data.getL2Sid()));
            // String l2ParentID=businessUnitsMap.get(l2Data.getBusinessUnit());
            title=objectDataUtil.setConfluenceTitle(l2Data.getL2Sid(), l2Data.getL2Name());
            tableData=getL2TableData(l2Data);
            childTitles=l2KeyL3TitlesMap.get(l2Data.getL2Sid());
            /*RequestDTO requestDTO=objectDataUtil.getUpdatedObjectFromConfluenceData(title);
            objectDataUtil.updateTableAndLinksData(requestDTO, tableData,childTitles);*/
        }

        System.out.println("=====End L2Data update=====");
    }

    private void updateL3Data() {
        System.out.println("Start l3Data update");
        List<Object[]> l4Titles = daoImpl.getL4TitlesData();
        Map<String, List<String>> l3KeyL4TitlesMap = objectDataUtil.getChildList(l4Titles);

        String title="";
        String tableData="";
        List<String> childTitles=null;

        List<L3Data> l3DataList=daoImpl.getL3Data(config.getStatusUpdate());
        for (L3Data l3Data : l3DataList) {
            title=objectDataUtil.setConfluenceTitle(l3Data.getL3Ssid(), l3Data.getL3Name());
            tableData=getL3TableData(l3Data);
            childTitles=l3KeyL4TitlesMap.get(l3Data.getL3Ssid());
            RequestDTO requestDTO=objectDataUtil.getUpdatedObjectFromConfluenceData(title);
            objectDataUtil.updateTableAndLinksData(requestDTO, tableData,childTitles);
        }

        System.out.println("End l3Data update");
    }

    private void updateL4Data() {
        System.out.println("=====Start L4Data update=====");

        String l4ParentID=tsTemplateMap.get(config.getTs_L4_PageKey());

        List<L4Data> l4DataList = daoImpl.getL4Data(config.getStatusUpdate());
        System.out.println(l4DataList);

        List<Object[]> l5Titles = daoImpl.getL5TitlesData();

        Map<String, List<String>> l4KeyL5TitlesMap = objectDataUtil.getChildList(l5Titles);

        String title="";
        String tableData="";
        List<String> childTitles=null;
        if (StringUtil.isNotBlank(l4ParentID)) {
            for (L4Data l4Data : l4DataList) {
                title=objectDataUtil.setConfluenceTitle(l4Data.getSoftwareLicenceExternalId(), l4Data.getApplicationName());
                tableData=getL4TableData(l4Data);
                childTitles=l4KeyL5TitlesMap.get(l4Data.getCCid());
                RequestDTO requestDTO=objectDataUtil.getUpdatedObjectFromConfluenceData(title);
                objectDataUtil.updateTableAndLinksData(requestDTO, tableData,childTitles);
            }
        }
        System.out.println("=====End L4Data update=====");
    }

    private void updateL5Data() {
        System.out.println("=====Start L5Data update=====");

        String l5ParentID=tsTemplateMap.get(config.getTs_L5_PageKey());

        List<L5Data> l5DataList = daoImpl.getL5Data(config.getStatusUpdate());

        List<Object[]> l6Titles = daoImpl.getL6TitlesData();

        Map<String, List<String>> l5KeyL6TitlesMap = objectDataUtil.getChildList(l6Titles);

        String title="";
        String tableData="";
        List<String> childTitles=null;
        if (StringUtil.isNotBlank(l5ParentID)) {
            for (L5Data l5Data : l5DataList) {
                title=objectDataUtil.setConfluenceTitle(l5Data.getL5_cid(), l5Data.getL5_cid_name());
                tableData=getL5TableData(l5Data);
                childTitles=l5KeyL6TitlesMap.get(l5Data.getL5_cid());
                RequestDTO requestDTO=objectDataUtil.getUpdatedObjectFromConfluenceData(title);
                objectDataUtil.updateTableAndLinksData(requestDTO, tableData,childTitles);
            }
        }

        System.out.println("=====End L5Data update=====");
    }

    private void updateL6Data() {
        System.out.println("=====Start L6Data Process=====");

        String l6ParentID=tsTemplateMap.get(config.getTs_L6_PageKey());

        List<L6Data> l6DataList = daoImpl.getL6Data(config.getStatusUpdate());
        System.out.println(l6DataList);

        String title="";
        String tableData="";
        if (StringUtil.isNotBlank(l6ParentID)) {
            for (L6Data l6Data : l6DataList) {
                title = objectDataUtil.setConfluenceTitle(l6Data.getL6_cid(), l6Data.getL6_cid_name());
                tableData=getL6TableData(l6Data);
                RequestDTO requestDTO=objectDataUtil.getUpdatedObjectFromConfluenceData(title);
                objectDataUtil.updateTableAndLinksData(requestDTO, tableData,null);
            }
        }

        System.out.println("=====End L6Data update=====");
    }

    /** End update L1 to L6 */

    /** Start Create L1 to L6  */

    private void createL1Data() {
        System.out.println("create L1Data Start ");
        String l1ParentID=baseTemplateMap.get(config.getIbs_PageKey());
        if (StringUtil.isNotBlank(l1ParentID)) {
            List<L1Data> l1DataList = daoImpl.getL1Data(config.getStatusNew());

            List<Object[]> l2Titles = daoImpl.getL2TitlesData();

            Map<String, String> l1KeyL2TitlesMap = objectDataUtil.getChildLinks(l2Titles);
            List<RequestModel> newL1DataList = new ArrayList<>();
            RequestModel requestModel;
            String title="";
            String tableData="";
            String links="";
            for (L1Data l1Data : l1DataList) {
                // l1Data.setL2TitleList(l1KeyL2TitlesMap.get(l1Data.getIbs_l1()));

                title=objectDataUtil.setConfluenceTitle(l1Data.getSr_no() + "", l1Data.getImportant_business_service());

                tableData=getL1TableData(l1Data);

                links=l1KeyL2TitlesMap.get(l1Data.getIbs_l1());
                links=links !=null?getFinalLinksForm(AppConstants.l1ChildLinkName, links):null;

                requestModel=setDataToRequest(title,tableData,links, l1ParentID);

                if (requestModel != null && StringUtil.isNotBlank(title)) {
                    requestModel.setKeyValue(l1Data.getSr_no() + "");
                    requestModel.setStatusType(l1Data.getStatusType());
                    newL1DataList.add(requestModel);
                }

            }
            System.out.println("newL1DataList size ==>" + newL1DataList.size());

            if (newL1DataList.size() > 0) {
                objectDataUtil.lastChildRequestModel(newL1DataList);
            }
        }
    }

    private void createL2Data() {
        System.out.println("=====Start L2Data Process=====");

        List<L2Data> l2DataList = daoImpl.getL2Data(config.getStatusNew());
        System.out.println("l2DataList "+l2DataList.size());


        List<Object[]> l3Titles = daoImpl.getL3TitlesData();

        Map<String, String> l2KeyL3TitlesMap = objectDataUtil.getChildLinks(l3Titles);
        List<RequestModel> newL2DataList = new ArrayList<>();
        RequestModel requestModel;
        String title="";
        String tableData="";
        String links="";
        for (L2Data l2Data : l2DataList) {
            // l2Data.setL3TitleList(l2KeyL3TitlesMap.get(objectDataUtil.validateString(l2Data.getL2Sid())));
            String l2ParentID=businessUnitsMap.get(objectDataUtil.validateString(l2Data.getBusinessUnit()));
            title=objectDataUtil.setConfluenceTitle(l2Data.getL2Sid(), l2Data.getL2Name());
            tableData=getL2TableData(l2Data);

            links=l2KeyL3TitlesMap.get(l2Data.getL2Sid());
            links=links !=null?getFinalLinksForm(AppConstants.l2ChildLinkName, links):null;

            requestModel=setDataToRequest(title,tableData,links, l2ParentID);
            if (StringUtil.isNotBlank(l2ParentID) && requestModel != null && StringUtil.isNotBlank(title)) {
                requestModel.setKeyValue(l2Data.getL2Sid());
                requestModel.setStatusType(l2Data.getStatusType());
                newL2DataList.add(requestModel);
            }
        }
        System.out.println("newL2DataList==>" + newL2DataList.size());

        if (newL2DataList.size() > 0) {
            objectDataUtil.lastChildRequestModel(newL2DataList);
            createL3Data(newL2DataList);
        }
    }

    private void createL3Data(List<RequestModel> newL2DataList) {
        System.out.println("Start l3Data create");
        String l3ParentID;
        List<Object[]> l4Titles = daoImpl.getL4TitlesData();
        Map<String, String> l3KeyL4TitlesMap = objectDataUtil.getChildLinks(l4Titles);
        List<RequestModel> newL3DataList = new ArrayList<>();
        RequestModel requestModel1;
        String title="";
        String tableData="";
        String links="";
        for (RequestModel requestModel:newL2DataList) {
            l3ParentID=requestModel.getRequestDTO().getId();
            List<L3Data> l3DataList=daoImpl.getL3BasedOnL2Key(requestModel.getKeyValue());
            if (StringUtil.isNotBlank(l3ParentID)) {
                for (L3Data l3Data : l3DataList) {
                    // l3Data.setL4TitleList(l3KeyL4TitlesMap.get(l3Data.getL3Ssid()));
                    title=objectDataUtil.setConfluenceTitle(l3Data.getL3Ssid(), l3Data.getL3Name());

                    tableData=getL3TableData(l3Data);

                    links=l3KeyL4TitlesMap.get(l3Data.getL3Ssid());
                    links=links!=null?getFinalLinksForm(AppConstants.l3ChildLinkName,links):null;

                    requestModel1 = setDataToRequest(title,tableData,links, l3ParentID);

                    if (requestModel1 != null && StringUtil.isNotBlank(title)
                            && l3Data.getStatusType().equals(config.getStatusNew())) {
                        requestModel.setKeyValue(l3Data.getL3Ssid());
                        requestModel.setStatusType(l3Data.getStatusType());
                        newL3DataList.add(requestModel1);
                    }
                }
            }
        }
        System.out.println("newL3DataList size ==>" + newL3DataList.size());

        if (newL3DataList.size() > 0) {
            objectDataUtil.lastChildRequestModel(newL3DataList);
        }
    }

    private void createL4Data() {
        System.out.println("=====Start L4Data Process=====");

        String l4ParentID=tsTemplateMap.get(config.getTs_L4_PageKey());

        List<L4Data> l4DataList = daoImpl.getL4Data(config.getStatusNew());

        List<Object[]> l5Titles = daoImpl.getL5TitlesData();

        Map<String, String> l2KeyL3TitlesMap = objectDataUtil.getChildLinks(l5Titles);

        List<RequestModel> newL4DataList = new ArrayList<>();
        RequestModel requestModel;
        String title="";
        String tableData="";
        String links="";
        if (StringUtil.isNotBlank(l4ParentID)) {
            for (L4Data l4Data : l4DataList) {
                l4Data.setL5TitleList(l2KeyL3TitlesMap.get(l4Data.getCCid()));

                title=objectDataUtil.setConfluenceTitle(l4Data.getSoftwareLicenceExternalId(), l4Data.getApplicationName());

                tableData=getL4TableData(l4Data);

                links=l2KeyL3TitlesMap.get(l4Data.getCCid());
                links=links!=null?getFinalLinksForm(AppConstants.l4ChildLinkName,links):null;

                requestModel=setDataToRequest(title,tableData,links,l4ParentID);

                if (requestModel != null && StringUtil.isNotBlank(title)) {
                    requestModel.setKeyValue(l4Data.getSoftwareLicenceExternalId());
                    requestModel.setStatusType(l4Data.getStatusType());
                    newL4DataList.add(requestModel);
                }
            }
        }
        System.out.println("newL4DataList size==>" + newL4DataList.size());

        if (newL4DataList.size() > 0) {
            objectDataUtil.lastChildRequestModel(newL4DataList);
        }
    }

    private void createL5Data() {
        System.out.println("=====Start L5Data Process=====");

        String l5ParentID=tsTemplateMap.get(config.getTs_L5_PageKey());

        List<L5Data> l5DataList = daoImpl.getL5Data(AppConstants.StatusNew);

        List<Object[]> l6Titles = daoImpl.getL6TitlesData();

        Map<String, String> l5KeyL6TitlesMap = objectDataUtil.getChildLinks(l6Titles);

        List<RequestModel> newL5DataList = new ArrayList<>();
        RequestModel requestModel;
        String title="";
        String tableData="";
        String links="";
        if (StringUtil.isNotBlank(l5ParentID)) {
            for (L5Data l5Data : l5DataList) {
                l5Data.setL6TitleList(l5KeyL6TitlesMap.get(l5Data.getL5_cid()));

                title=objectDataUtil.setConfluenceTitle(l5Data.getL5_cid(), l5Data.getL5_cid_name());

                tableData=getL5TableData(l5Data);

                links=l5KeyL6TitlesMap.get(l5Data.getL5_cid());
                links=links!=null?getFinalLinksForm(AppConstants.l5ChildLinkName,links):null;

                requestModel = setDataToRequest(title,tableData,links,l5ParentID);

                if (requestModel != null && StringUtil.isNotBlank(title)) {
                    requestModel.setKeyValue(l5Data.getL5_cid());
                    requestModel.setStatusType(l5Data.getStatusType());
                    newL5DataList.add(requestModel);
                }
            }
        }
        System.out.println("newL5DataList size==>" + newL5DataList.size());

        if (newL5DataList.size() > 0) {
            objectDataUtil.lastChildRequestModel(newL5DataList);
        }
    }

    private void createL6Data() {
        System.out.println("=====Start L6Data Process=====");

        String l6ParentID=tsTemplateMap.get(config.getTs_L6_PageKey());

        List<L6Data> l6DataList = daoImpl.getL6Data(AppConstants.StatusNew);

        List<RequestModel> newL6DataList = new ArrayList<>();
        RequestModel requestModel;
        String title ="";
        String tableData="";
        if (StringUtil.isNotBlank(l6ParentID)) {
            for (L6Data l6Data : l6DataList) {
                title = objectDataUtil.setConfluenceTitle(l6Data.getL6_cid(), l6Data.getL6_cid_name());

                tableData=getL6TableData(l6Data);

                requestModel = setDataToRequest(title,tableData,null,l6ParentID);

                if (StringUtil.isNotBlank(title) && requestModel != null) {
                    requestModel.setKeyValue(l6Data.getL6_cid());
                    requestModel.setStatusType(l6Data.getStatusType());
                    newL6DataList.add(requestModel);
                }
            }
        }
        System.out.println("newL6DataList size==>" + newL6DataList.size());

        if (newL6DataList.size() > 0) {
            objectDataUtil.lastChildRequestModel(newL6DataList);
        }
    }

    /** End Create L1 to L6  */

    private String getL1TableData(L1Data l1Data) {
        StringBuffer trData = new StringBuffer();

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Owner")
                + dataUtil.buildTD(objectDataUtil.validateString(l1Data.getService_owner()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Definition")
                + dataUtil.buildTD(objectDataUtil.validateString(l1Data.getDefinition()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("DownTime Impact")
                + dataUtil.buildTD(objectDataUtil.validateString(l1Data.getDowntime_impact()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Scope")
                + dataUtil.buildTD(objectDataUtil.validateString(l1Data.getScope()))));

        String tableData = dataUtil.buildTable(trData);
        return tableData;
    }

    private String getL2TableData(L2Data l2Data) {
        StringBuffer trData = new StringBuffer();

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Business Unit")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getBusinessUnit()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Name")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getServiceName()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Business Division")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getBusinessDivision()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Description")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getServiceDescription()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Owner")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getServiceOwner()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Criticality")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getServiceCriticality()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Importance")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getServiceImportance()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Economic Function ")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getEconomicFunction()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Channels")
                + dataUtil.buildTD(objectDataUtil.validateString(l2Data.getChannels()))));

        String tableData = dataUtil.buildTable(trData);
        return tableData;
    }

    private String getL3TableData(L3Data l3Data) {
        StringBuffer trData = new StringBuffer();

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Business Unit")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getBusinessUnit()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Name")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getServiceName()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Assignment Group")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getAssignmentGroup()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Sub Service ID")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getSubServiceId()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Data Type")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getDataType()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Data Source")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getDataSource()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Data Set Description")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getDataSetDescription()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Data Owner")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getDataOwner()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Criticality")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getServiceCriticality()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("SLA No")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getSlaNo()))));
        trData.append(dataUtil.buildTR(dataUtil.buildTH("Schemes")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getSchemes()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Manager")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getServiceManager()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Policies")
                + dataUtil.buildTD(objectDataUtil.validateString(l3Data.getPolicies()))));

        String tableData = dataUtil.buildTable(trData);
        return tableData;
    }

    private String getL4TableData(L4Data l4Data) {
        StringBuffer trData = new StringBuffer();

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Business Domain")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getBusinessDomain()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("L3 Service Name")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getL3ServiceName()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Metamodel")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getMetamodel()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Owner (Assignment Group?)")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getApplicationOwner()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("CIID")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getCCidName()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Functions")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getApplicationFunctions()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Criticality or CAT of Service")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getCriticalityOrCatOfService()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Details (freeform text)")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getDetails()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Regulatory or SOX Compliance")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getRegulatoryOrSoxCompliance()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Assignment Group")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getAssignmentGroup()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Support Groups")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getSupportGroups()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Provider")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getProvider()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Type")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getApplicationType()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Predecessors")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getPredecessors()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Obsolescence Score")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getObsolescenceScore()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Architecture links (Application)")
                + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getArchitectureLinks()))));

        String tableData = dataUtil.buildTable(trData);
        return tableData;
    }

    private String getL5TableData(L5Data l5Data) {
        StringBuffer trData = new StringBuffer();

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Provider or 3rd Party")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getProvider_or_3rdparty()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Technical Services (Product or Technology)")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getTechnical_services()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Reference Compliance level")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getReference_compliance_level()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("APIs exposed")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getApis_exposed()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Infrastructure diagrams (TA and SA)")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getInfrastructure_diagrams()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Predecessors")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getPredecessors()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Criticality or CAT if Service")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getCriticality()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Successors (are there any plan system)")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getSuccessors()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Obsolescence Score")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getObsolescence_score()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Manager")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getService_manager()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("GIT repos")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getGit_repos()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Pipeline")
                + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getPipeline()))));

        String tableData = dataUtil.buildTable(trData);
        return tableData;
    }

    private String getL6TableData(L6Data l6Data) {
        StringBuffer trData = new StringBuffer();

        trData.append(dataUtil.buildTR(dataUtil.buildTH("L6 CI")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getL6ci()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Status")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getStatus()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("DNS")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDns()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("OS")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getOs()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Status")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getStatus()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("DC")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDc()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("In use?")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getIn_use()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Criticality or CAT if Service")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getCriticality_or_cat_of_service()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("F5 VIPS")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getF5_vips()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("DBI name")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDbi_name()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("DBI type")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDbi_type()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Vmware Datastore and cluster")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getVmware_datastore_and_cluster()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Obsolete Date")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getObsolete_date()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Paas information")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getPaas_information()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("Microservices")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getMicroservices()))));

        trData.append(dataUtil.buildTR(dataUtil.buildTH("API swagger definition")
                + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getApi_swagger_definition()))));

        String tableData = dataUtil.buildTable(trData);
        return tableData;
    }

    private String getFinalLinksForm(String serviceName, String links) {
        String ulData = dataUtil.buildUL(links);
        ulData = dataUtil.buildUL(serviceName + ulData);
        return ulData;
    }

    private RequestModel setDataToRequest(String title, String tableData,String links, String parentID) {
        RequestModel requestModel = null;
        if (StringUtil.isNotBlank(title)) {
            requestModel = new RequestModel();
            RequestDTO requestDTO = dataUtil.getBasicRequestDTO(title);
            if (StringUtil.isNotBlank(links)) {
                requestModel.setChild(true);
                requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(title, tableData, links,true)));
            } else {
                requestModel.setChild(false);
                requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(title, tableData)));
            }
            requestDTO.setAncestors(dataUtil.getListAncestor(parentID));
            requestModel.setRequestDTO(requestDTO);
        }
        return requestModel;
    }


    /*private RequestModel setL2DataToRequest(L2Data l2Data, String l2ParentID) {
        RequestModel requestModel = null;
        String title=objectDataUtil.setConfluenceTitle(l2Data.getL2Sid(), l2Data.getL2Name());
        if (StringUtil.isNotBlank(title)) {
            requestModel = new RequestModel();
            RequestDTO requestDTO = dataUtil.getBasicRequestDTO(title);
            StringBuffer trData = new StringBuffer();


            String tableData = dataUtil.buildTable(trData);
            String businessService = "Sub Service";
            String ulData = dataUtil.buildUL(l2Data.getL3TitleList());
            ulData = dataUtil.buildUL(businessService + ulData);
            requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(tableData, ulData)));
            requestDTO.setAncestors(dataUtil.getListAncestor(l2ParentID));
            requestDTO.setId(l2Data.getPageId());
            requestModel.setRequestDTO(requestDTO);
            requestModel.setKeyValue(l2Data.getL2Sid());
            requestModel.setStatusType(l2Data.getStatusType());
        }
        return requestModel;
    }

    private RequestModel setL3DataToRequest(L3Data l3Data, String l3ParentID) {
        RequestModel requestModel = null;
        String title=objectDataUtil.setConfluenceTitle(l3Data.getL3Ssid(), l3Data.getL3Name());
        if (StringUtil.isNotBlank(title)) {
            requestModel = new RequestModel();
            RequestDTO requestDTO = dataUtil.getBasicRequestDTO(title);
            StringBuffer trData = new StringBuffer();



            String tableData = dataUtil.buildTable(trData);
            String businessService = "Technical Service";
            String ulData = dataUtil.buildUL(l3Data.getL4TitleList());
            ulData = dataUtil.buildUL(businessService + ulData);
            requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(tableData, ulData)));
            requestDTO.setAncestors(dataUtil.getListAncestor(l3ParentID));
            requestDTO.setId(l3Data.getPageId());
            requestModel.setRequestDTO(requestDTO);
            requestModel.setKeyValue(l3Data.getL3Ssid());
            requestModel.setStatusType(l3Data.getStatusType());
        }
        return requestModel;
    }

    private RequestModel setL4DataToRequest(L4Data l4Data, String l4ParentID) {
        RequestModel requestModel = null;
        String title=objectDataUtil.setConfluenceTitle(l4Data.getSoftwareLicenceExternalId(), l4Data.getApplicationName());
        if (StringUtil.isNotBlank(title)) {
            requestModel = new RequestModel();
            RequestDTO requestDTO = dataUtil.getBasicRequestDTO(title);
            StringBuffer trData = new StringBuffer();

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Business Domain")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getBusinessDomain()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("L3 Service Name")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getL3ServiceName()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Metamodel")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getMetamodel()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Owner (Assignment Group?)")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getApplicationOwner()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("CIID")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getCCidName()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Functions")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getApplicationFunctions()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Criticality or CAT of Service")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getCriticalityOrCatOfService()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Details (freeform text)")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getDetails()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Regulatory or SOX Compliance")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getRegulatoryOrSoxCompliance()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Assignment Group")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getAssignmentGroup()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Support Groups")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getSupportGroups()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Provider")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getProvider()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Type")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getApplicationType()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Predecessors")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getPredecessors()))));
            
            trData.append(dataUtil.buildTR(dataUtil.buildTH("Obsolescence Score")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getObsolescenceScore()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Architecture links (Application)")
                    + dataUtil.buildTD(objectDataUtil.validateString(l4Data.getArchitectureLinks()))));


            String tableData = dataUtil.buildTable(trData);
            String businessService = "Sub Technical Service";
            String ulData = dataUtil.buildUL(l4Data.getL5TitleList());
            ulData = dataUtil.buildUL(businessService + ulData);
            requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(tableData, ulData)));
            requestDTO.setAncestors(dataUtil.getListAncestor(l4ParentID));
            requestDTO.setId(l4Data.getPageId());
            requestModel.setRequestDTO(requestDTO);
            requestModel.setKeyValue(l4Data.getSoftwareLicenceExternalId());
            requestModel.setStatusType(l4Data.getStatusType());
        }
        return requestModel;
    }

    private RequestModel setL5DataToRequest(L5Data l5Data, String l5ParentID) {
        RequestModel requestModel = null;
        String title=objectDataUtil.setConfluenceTitle(l5Data.getL5_cid(),l5Data.getL5_cid_name());
        if (StringUtil.isNotBlank(title)) {
            requestModel = new RequestModel();
            RequestDTO requestDTO = dataUtil.getBasicRequestDTO(title);
            StringBuffer trData = new StringBuffer();

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Provider or 3rd Party")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getProvider_or_3rdparty()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Technical Services (Product or Technology)")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getTechnical_services()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Reference Compliance level")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getReference_compliance_level()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("APIs exposed")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getApis_exposed()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Infrastructure diagrams (TA and SA)")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getInfrastructure_diagrams()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Predecessors")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getPredecessors()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Criticality or CAT if Service")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getCriticality()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Successors (are there any plan system)")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getSuccessors()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Obsolescence Score")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getObsolescence_score()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Service Manager")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getService_manager()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("GIT repos")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getGit_repos()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Pipeline")
                    + dataUtil.buildTD(objectDataUtil.validateString(l5Data.getPipeline()))));

            String tableData = dataUtil.buildTable(trData);
            String businessService = "Sub Technical Service";
            String ulData = dataUtil.buildUL(l5Data.getL6TitleList());
            ulData = dataUtil.buildUL(businessService + ulData);
            requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(tableData, ulData)));
            requestDTO.setAncestors(dataUtil.getListAncestor(l5ParentID));
            requestDTO.setId(l5Data.getPageId());
            requestModel.setRequestDTO(requestDTO);
            requestModel.setKeyValue(l5Data.getL5_cid());
            requestModel.setStatusType(l5Data.getStatusType());
        }
        return requestModel;
    }

    private RequestModel setL6DataToRequest(L6Data l6Data, String l6ParentID) {
        RequestModel requestModel = null;
        String title=objectDataUtil.setConfluenceTitle(l6Data.getL6_cid(),l6Data.getL6_cid_name());
        if (StringUtil.isNotBlank(title)) {
            requestModel = new RequestModel();
            RequestDTO requestDTO = dataUtil.getBasicRequestDTO(title);
            StringBuffer trData = new StringBuffer();

            trData.append(dataUtil.buildTR(dataUtil.buildTH("L6 CI")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getL6ci()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Application Status")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getStatus()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("DNS")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDns()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("OS")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getOs()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Status")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getStatus()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("DC")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDc()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("In use?")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getIn_use()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Criticality or CAT if Service")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getCriticality_or_cat_of_service()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("F5 VIPS")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getF5_vips()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("DBI name")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDbi_name()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("DBI type")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getDbi_type()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Vmware Datastore and cluster")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getVmware_datastore_and_cluster()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Obsolete Date")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getObsolete_date()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Paas information")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getPaas_information()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("Microservices")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getMicroservices()))));

            trData.append(dataUtil.buildTR(dataUtil.buildTH("API swagger definition")
                    + dataUtil.buildTD(objectDataUtil.validateString(l6Data.getApi_swagger_definition()))));


            String tableData = dataUtil.buildTable(trData);

            requestDTO.setBody(dataUtil.getBody(dataUtil.layOutTemplate(tableData, null)));
            requestDTO.setAncestors(dataUtil.getListAncestor(l6ParentID));
            requestDTO.setId(l6Data.getPageId());
            requestModel.setChild(false);
            requestModel.setRequestDTO(requestDTO);
            requestModel.setKeyValue(l6Data.getL6_cid());
            requestModel.setStatusType(l6Data.getStatusType());
        }
        return requestModel;
    }*/

    

}
