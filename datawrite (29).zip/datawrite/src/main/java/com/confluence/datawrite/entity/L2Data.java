package com.confluence.datawrite.entity;

import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "l2_data")
public class L2Data {
    @Id
    private Long id;
    @Column(name = "l1_sid")
    private String l1Sid;
    @Column(name = "l2_sid")
    private String l2Sid;
    @Column(name = "l2_name")
    private String l2Name;
    @Column(name = "service_name")
    private String serviceName;
    @Column(name = "business_unit")
    private String businessUnit;
    @Column(name = "business_division")
    private String businessDivision;
    @Column(name = "service_description")
    private String serviceDescription;


    @Column(name = "service_owner")
    private String serviceOwner;
    @Column(name = "service_criticality")
    private String serviceCriticality;
    @Column(name = "service_importance")
    private String serviceImportance;
    @Column(name = "economic_function")
    private String economicFunction;
    @Column(name = "channels")
    private String channels;

    @Column(name = "status_type")
    private String statusType;

    @Transient
    private String l3TitleList;

    @Transient
    private String pageId;

    /*@ManyToOne(fetch = FetchType.EAGER)
    @JsonIgnore
    @JoinColumn(referencedColumnName = "ibs_l1", nullable = false)
    private L1Data l1Data;*/


}
