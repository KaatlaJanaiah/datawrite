package com.confluence.datawrite.model;

import lombok.Data;

@Data
public class Ancestor {
    private String id;
    private String type;
    // private String title;
    // private String _links;
}
