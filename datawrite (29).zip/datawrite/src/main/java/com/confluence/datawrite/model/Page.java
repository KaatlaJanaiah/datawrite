package com.confluence.datawrite.model;

import lombok.Data;

import java.util.List;
@Data
public class Page {
    private List results;
    private String start;
    private String limit;
    private Integer size;
    private Object _links;
}
