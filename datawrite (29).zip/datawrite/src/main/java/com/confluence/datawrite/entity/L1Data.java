package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.*;
import java.util.List;

@Data
@Entity
@Table(name = "l1_data")
public class L1Data {
    @Id
    private Long id;
    private Long sr_no;
    private String ibs_l1;
    private String important_business_service;
    private String service_owner;
    private String definition;
    private String downtime_impact;
    private String scope;
    @Column(name = "status_type")
    private String statusType;

    @Transient
    private String l2TitleList;

    @Transient
    private String pageId;


}
