package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "l6_data")
public class L6Data {

    @Id
    private Long id;
    private String l5_cid;
    private String l5_cid_name;
    private String l6_cid;
    private String l6_cid_name;
    private String l6ci;
    private String l6name;
    private String dns;
    private String os;
    private String status;
    private String dc;
    private String in_use;
    private String criticality_or_cat_of_service;
    private String f5_vips;
    private String dbi_name;
    private String dbi_type;
    private String vmware_datastore_and_cluster;
    private String obsolete_date;
    private String paas_information;
    private String microservices;
    private String api_swagger_definition;
    @Column(name = "status_type")
    private String statusType;

    @Transient
    private String pageId;
}
