package com.confluence.datawrite.config;

import lombok.Data;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;

import java.util.HashMap;
import java.util.Map;

@Configuration
@Data
public class Config {
    @Value("${confluence.api.endpoint}")
    private String confluenceAPIEndPoint;

    @Value("${confluence.api.space.endpoint}")
    private String confluenceAPISpaceEndPoint;

    @Value("${confluence.basic.authToken}")
    private String confluenceAuthToken;

    @Value("${data.file.path}")
    private String excelPath;

    @Value("${confluence.space.key}")
    private String spaceKey;

    @Value("${data.ibs_PageKey}")
    private String ibs_PageKey;

    @Value("${data.bs_PageKey}")
    private String bs_PageKey;

    @Value("${data.ts_PageKey}")
    private String ts_PageKey;

    @Value("${data.ts_L4_PageKey}")
    private String ts_L4_PageKey;

    @Value("${data.ts_L5_PageKey}")
    private String ts_L5_PageKey;

    @Value("${data.ts_L6_PageKey}")
    private String ts_L6_PageKey;

    private String fail="Failed";

    private String StatusNew="New";
    private String StatusUpdate="Update";
    private String StatusDelete="Delete";

}
