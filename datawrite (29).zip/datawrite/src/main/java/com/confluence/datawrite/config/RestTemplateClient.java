package com.confluence.datawrite.config;

import org.springframework.beans.factory.annotation.Configurable;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.web.client.RestTemplateBuilder;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Primary;
import org.springframework.http.client.BufferingClientHttpRequestFactory;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.http.converter.json.MappingJackson2HttpMessageConverter;
import org.springframework.web.client.RestTemplate;

import java.time.Duration;

@Configurable
public class RestTemplateClient {

    /*@Bean
    @Qualifier("restTemplate")
    public RestTemplate restTemplate(RestTemplateBuilder builder) {
        return builder.setConnectTimeout(Duration.ofMillis(300000))
                .setReadTimeout(Duration.ofMillis(300000)).build();
    }*/

    @Bean
    @Qualifier("restTemplate")
    @Primary
    public RestTemplate restTemplate(RestTemplateBuilder restTemplateBuilder){

        RestTemplate restTemplate = new RestTemplate();
                /*restTemplateBuilder.requestFactory(new BufferingClientHttpRequestFactory(new SimpleClientHttpRequestFactory()))
                // .interceptors(logRestRequestInterceptor) //This is your custom interceptor bean
                .messageConverters(new MappingJackson2HttpMessageConverter())
                .build();*/
        return restTemplate;


    }
}
