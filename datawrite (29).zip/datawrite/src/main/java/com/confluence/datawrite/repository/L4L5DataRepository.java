package com.confluence.datawrite.repository;

import com.confluence.datawrite.config.AppConstants;
import com.confluence.datawrite.entity.L3Data;
import com.confluence.datawrite.entity.L4L5Data;
import com.confluence.datawrite.entity.L5Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface L4L5DataRepository extends JpaRepository<L4L5Data, Long> {

    public static final String FIND_L5Titles = "SELECT l4_ccid, concat(l5_cid, ' - ', l5_cid_name) FROM l4_l5_data where status_type !='"+ AppConstants.StatusDelete +"'";

    @Query(value = FIND_L5Titles, nativeQuery = true)
    public List<Object[]> findL4KeyL5Titles();

    public static final String FIND_L5ParentTitles = "SELECT concat(l4_software_licence_external_id, ' - ', l4_application_name) FROM l4_l5_data where l5_cid=?";

    @Query(value = FIND_L5ParentTitles, nativeQuery = true)
    public List<Object[]> findL5KeyL4Titles(String l5_cid);

    List<L4L5Data> findByStatusType(String statusType);
}
