package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "l3_l4_data")
public class L3L4Data {
    @Id
    private Long id;
    private String l4_software_licence_external_id;
    private String l4_application_name;
    private String l3_service_name;
    private String l4_ccid;
    private String l4_ccid_name;
    private String ssid;
    @Column(name = "status_type")
    private String statusType;
}
