package com.confluence.datawrite.model;

import lombok.Data;

import java.util.List;

@Data
public class ConfluenceData {
    private String id;
    private String type;
    private String title;
    private ConfluenceBody body;
    private List ancestors;
    private Object macroRenderedOutput;
    private Object extensions;
    private Object _expandable;
    private Object _links;
    private Object status;
}
