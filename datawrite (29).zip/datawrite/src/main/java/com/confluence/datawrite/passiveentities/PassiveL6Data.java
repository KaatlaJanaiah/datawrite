package com.confluence.datawrite.passiveentities;

public class PassiveL6Data {
}
