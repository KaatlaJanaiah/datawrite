package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.L3Data;
import com.confluence.datawrite.entity.L4Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface L4DataRepository extends JpaRepository<L4Data, Long> {

    List<L4Data> findByStatusType(String statusType);


}
