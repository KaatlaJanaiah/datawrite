package com.confluence.datawrite.model;

import lombok.Data;

@Data
public class ConfluenceBody {
    private ConfluenceStorage storage;
    private Object _expandable;
}
