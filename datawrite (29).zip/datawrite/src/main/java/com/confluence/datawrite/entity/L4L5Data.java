package com.confluence.datawrite.entity;

import lombok.Data;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Data
@Entity
@Table(name = "l4_l5_data")
public class L4L5Data {
    @Id
    private Long id;
    @Column(name="l4_ccid")
    private String l4Ccid;
    @Column(name="l4_cid_name")
    private String l4CidName;
    @Column(name="l5_cid")
    private String l5Cid;
    @Column(name="l5_cid_name")
    private String l5CidName;

    @Column(name = "status_type")
    private String statusType;

}
