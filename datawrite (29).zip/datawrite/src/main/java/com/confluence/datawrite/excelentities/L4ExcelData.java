package com.confluence.datawrite.excelentities;

public class L4ExcelData {
}
