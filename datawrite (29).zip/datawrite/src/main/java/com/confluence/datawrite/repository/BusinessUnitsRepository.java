package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.BusinessUnits;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface BusinessUnitsRepository extends JpaRepository<BusinessUnits, Long> {

    Optional<BusinessUnits> findByTemplateName(String templateName);
}
