package com.confluence.datawrite.excelentities;

public class L1ExcelData {
}
