package com.confluence.datawrite.repository;

import com.confluence.datawrite.config.AppConstants;
import com.confluence.datawrite.entity.L1Data;
import com.confluence.datawrite.entity.L2Data;
import com.confluence.datawrite.entity.L3Data;
import org.springframework.data.domain.Example;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface L3DataRepository extends JpaRepository<L3Data, Long> {
    public static final String FIND_L3Titles = "SELECT l2_sid, concat(l3_ssid, ' - ', l3_name) FROM l3_data where l2_sid is not null and l2_sid != '' and status_type !='"+ AppConstants.StatusDelete +"'";

    public static final String FIND_L2Titles = "SELECT concat(l2_sid, ' - ', l2_service_name) FROM l3_data where l3_ssid= ?";

    @Query(value = FIND_L3Titles, nativeQuery = true)
    public List<Object[]> findL2KeyL3Titles();

    @Query(value = FIND_L2Titles, nativeQuery = true)
    public List<Object[]> findL3KeyL2Titles(String l3_ssid);

    List<L3Data> findByL2Sid(String l2Sid);

    List<L3Data> findByStatusType(String statusType);
}
