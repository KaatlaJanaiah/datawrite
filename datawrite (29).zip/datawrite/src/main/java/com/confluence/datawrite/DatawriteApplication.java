package com.confluence.datawrite;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatawriteApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatawriteApplication.class, args);
	}

}
