package com.confluence.datawrite.model;

import lombok.Data;

@Data
public class Space {
    private String key;
}
