package com.confluence.datawrite.repository;

import com.confluence.datawrite.config.AppConstants;
import com.confluence.datawrite.config.Config;
import com.confluence.datawrite.entity.L3Data;
import com.confluence.datawrite.entity.L4L5Data;
import com.confluence.datawrite.entity.L5L6Data;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface L5L6DataRepository extends JpaRepository<L5L6Data, Long> {


    public static final String FIND_L6Titles = "SELECT l5_cid, concat(l6_cid, ' - ', l6_cid_name) FROM l5_l6_data where status_type !='"+ AppConstants.StatusDelete +"'";

    @Query(value = FIND_L6Titles, nativeQuery = true)
    public List<Object[]> findL5KeyL6Titles();

    public static final String FIND_L5Titles = "SELECT concat(l5_cid, ' - ', l5_cid_name) FROM l5_l6_data where l6_cid=?";

    @Query(value = FIND_L5Titles, nativeQuery = true)
    public List<Object[]> findL6KeyL5Titles(String l6_cid);

    List<L5L6Data> findByStatusType(String statusType);
}
