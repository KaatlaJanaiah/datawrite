package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.L1Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface L1DataRepository extends JpaRepository<L1Data, Long> {

    /*@Query(value = "SELECT * FROM bookings bs WHERE " +
            "EXISTS (SELECT 1 FROM customer c WHERE bs.customer_id = c.id AND c.phone = :phone) " +
            "AND EXISTS (SELECT 1 FROM books b WHERE b.id = bs.book_id AND b.author IN :authors)",
            nativeQuery = true)*/

    /*@Query(value = "SELECT * FROM l1data l1 WHERE " +
            "EXISTS (SELECT 1 FROM l2data l2 WHERE l1.ibs_l1 = l2.l1_sid) ",
            nativeQuery = true)
    List<L1Data> findL1Data();*/

    List<L1Data> findByStatusType(String statusType);

}
