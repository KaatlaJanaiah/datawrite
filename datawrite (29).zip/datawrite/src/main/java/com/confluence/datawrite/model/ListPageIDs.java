package com.confluence.datawrite.model;

import lombok.Data;

import java.util.List;

@Data
public class ListPageIDs {
    private Page page;
    private Object blogpost;
    private Object _links;
}
