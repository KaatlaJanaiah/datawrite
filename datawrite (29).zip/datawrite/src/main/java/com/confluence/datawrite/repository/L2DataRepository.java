package com.confluence.datawrite.repository;

import com.confluence.datawrite.config.AppConstants;
import com.confluence.datawrite.entity.L1Data;
import com.confluence.datawrite.entity.L2Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface L2DataRepository extends JpaRepository<L2Data, Long> {

    public static final String FIND_L2Titles = "SELECT l1_sid, concat(l2_sid, ' - ', l2_name) FROM l2_data where l1_sid is not null and l1_sid != '' and status_type !='"+ AppConstants.StatusDelete +"'";

    public static final String FIND_L1Titles = "SELECT l1_title FROM l2_data where l2_sid=?";

    @Query(value = FIND_L2Titles, nativeQuery = true)
    public List<Object[]> findL1KeyL2Titles();

    @Query(value = FIND_L1Titles, nativeQuery = true)
    public List<Object[]> findL2KeyL1Titles(String l2_sid);

    public static final String FIND_BusinessUnits = "SELECT distinct business_unit FROM l2_data where business_unit not in (select template_name from business_units where page_id is not null and page_id !='')";

    @Query(value = FIND_BusinessUnits, nativeQuery = true)
    public List<Object[]> businessUnitsForCreate();

    List<L2Data> findByStatusType(String statusType);
}
