package com.confluence.datawrite.processor;


import com.confluence.datawrite.config.Config;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

@Component
public class DataProcessor implements InitializingBean {


    @Autowired
    private ExcelDataProcessor excelDataProcessor;

    @Autowired
    ServiceProcessor serviceProcessor;

    @Override
    public void afterPropertiesSet() {
        try {
            System.out.println("==============Processor Start===========");
            // excelDataProcessor.dataFlow();
            serviceProcessor.dataProcessor();
            /*int k=1;
            for (int i=0;i<k;i++) {
                excelDataProcessor.deletePages(0, 500);
            }*/
            System.out.println("==============Processor End===========");
        } catch (Exception e) {
            System.err.println("App Start - afterPropertiesSet==>"+e.getMessage());
        }
    
    }
}
