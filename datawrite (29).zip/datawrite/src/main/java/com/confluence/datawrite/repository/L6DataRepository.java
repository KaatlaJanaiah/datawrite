package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.L3Data;
import com.confluence.datawrite.entity.L6Data;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public interface L6DataRepository extends JpaRepository<L6Data, Long> {
    List<L6Data> findByStatusType(String statusType);
}
