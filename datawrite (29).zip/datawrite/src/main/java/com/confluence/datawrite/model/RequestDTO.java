package com.confluence.datawrite.model;

import lombok.Data;

import java.util.List;

@Data
public class RequestDTO {
   private String id;
   private String type;
   private String title;
   private Version version;
   private Space space;
   private List<Ancestor> ancestors;
   private Body body;
}
