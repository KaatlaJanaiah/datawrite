package com.confluence.datawrite.repository;

import com.confluence.datawrite.entity.BaseTemplate;
import com.confluence.datawrite.entity.TechnicalServiceTemplate;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

public interface TechnicalServiceTemplateRepository extends JpaRepository<TechnicalServiceTemplate, Long> {
    Optional<TechnicalServiceTemplate> findByTemplateName(String templateName);
}
